using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class MissionMachine : MonoBehaviour
{
    public GameObject missionsWindow;

    // Start is called before the first frame update
    private static int id;
    public Image machine;
    public GameObject Player;

    public GameObject claim1;
    public GameObject claim2;
    public GameObject claim3;
    public GameObject claim4; 

    public GameObject Quest1;
    public GameObject Quest2;
    public GameObject Quest3;
    public GameObject Quest4;

    public GameObject planete1;
    public GameObject planete2;
    public GameObject planete3;
    public GameObject planete4;

    public GameObject Earth;
    public GameObject Boss;

    private Text q1;
    private Text q2;
    private Text q3;
    private Text q4;

    public static bool Level1;
    public static bool Level2;
    public static bool Level3;
    public static bool Level4;

    private Image im1;
    private Image im2;
    private Image im3;
    private Image im4;

    private Image BossI;
    private Image EarthI;

    public GameObject LeBoss;

    public GameObject menuPause;
    public GameObject menuSave;
    public GameObject settings;

    public GameObject monstre1;
    public GameObject monstre2;
    void Start()
    {
        id = 0;
        q1 = Quest1.GetComponent<Text>();
        q2 = Quest2.GetComponent<Text>();
        q3 = Quest3.GetComponent<Text>();
        q4 = Quest4.GetComponent<Text>();
        im1 = claim1.GetComponent<Image>();
        im2 = claim2.GetComponent<Image>();
        im3 = claim3.GetComponent<Image>();
        im4 = claim4.GetComponent<Image>();

        BossI = Boss.GetComponent<Image>();
        EarthI = Earth.GetComponent<Image>();

        
    }

    // Update is called once per frame
    void Update()
    {      
        float x = Player.transform.position.x;
        float y = Player.transform.position.y;
        if (y > 2 && x < -4.5)
        {
            Message.sendMessage("PRESS T TO OPEN MISSION RECAP", ref id);
        }
        else
        {
            Message.clear(ref id);
        }

        bool isKeyDownT = Input.GetKeyDown(KeyCode.T);

        if (missionsWindow.active)
        {
            if (isKeyDownT)
            {
                missionsWindow.SetActive(false);
            }
            if ((y > 2 && x < -4.5) == false)
                CloseMissionsWindow();
        }
        else
        {
            if (isKeyDownT && y > 2 && x < -4.5 && !menuPause.active && !menuSave.active && !settings.active)
            {
                missionsWindow.SetActive(true);
                SetGoodLevel();
                if (Carte1.level == LEVEL.LEVEL1)
                {
                    Level1 = SetClaim(InventoryShip.getCount(3) >= 20, InventoryShip.getCount(6) >= 1, InventoryShip.getCount(0) >= 20, InventoryShip.getCount(8) >= 20);
                    Carte1.cp2 = Level1;
                }                 
                else if (Carte1.level == LEVEL.LEVEL2)
                {
                    Level2 = SetClaim(InventoryShip.getCount(1) >= 20, InventoryShip.getCount(5) >= 10, InventoryShip.getCount(2) >= 10, InventoryShip.getCount(9) >= 1);
                    Carte1.cp3 = Level2;
                }
                else if (Carte1.level == LEVEL.LEVEL3)
                {
                    Level3 = SetClaim(InventoryShip.getCount(2) >= 20, Minage.saber == Minage.SABER.YES, InventoryShip.getCount(0) >= 30, InventoryShip.getCount(8) >= 30);
                    Carte1.cp4 = Level3;
                }
                else if (Carte1.level == LEVEL.LEVEL4)
                {
                    Level4 = SetClaim(InventoryShip.getCount(2) >= 20, InventoryShip.getCount(0) >= 20, InventoryShip.getCount(1) >= 20,!(monstre1.active && monstre2.active));
                }
            }
        }
    }

    public void CloseMissionsWindow()
    {
        missionsWindow.SetActive(false);
    }

    public void SetGoodLevel()
    {
        if (Carte1.level == LEVEL.LEVEL1)
        {
            q1.text = "Get 20 iron ores";
            q2.text = "Make electric furnace";
            q3.text = "Get 20 iron ingots";
            q4.text = "Get 20 stones";

            SetQuestActive();
            SetClaimActive();

            planete1.SetActive(true);
            planete2.SetActive(false);
            planete3.SetActive(false);
            planete4.SetActive(false);
        }
        else if (Carte1.level == LEVEL.LEVEL2)
        {
            q1.text = "Get 20 copper ingots";
            q2.text = "Get 10 uranium ores";
            q3.text = "Get 10 uranium ingots";
            q4.text = "Get Reactor";

            SetQuestActive();
            SetClaimActive();

            planete1.SetActive(false);
            planete2.SetActive(true);
            planete3.SetActive(false);
            planete4.SetActive(false);

            Boss.SetActive(false);
            Earth.SetActive(false);
        }
        else if (Carte1.level == LEVEL.LEVEL3)
        {
            q1.text = "Get 20 uranium ingots";
            q2.text = "Get the lightsaber";
            q3.text = "Get 30 iron ingots";
            q4.text = "Mine 30 stones";

            SetQuestActive();
            SetClaimActive();

            planete1.SetActive(false);
            planete2.SetActive(false);
            planete3.SetActive(true);
            planete4.SetActive(false);

            Boss.SetActive(false);
            Earth.SetActive(false);
        }
        else if (Carte1.level == LEVEL.LEVEL4)
        {
            q1.text = "Get 20 uranium ingots";
            q2.text = "Get 20 iron ingots";
            q3.text = "Get 20 copper ingots";
            q4.text = "Kill the two monsters";

            SetQuestActive();
            SetClaimActive();

            planete1.SetActive(false);
            planete2.SetActive(false);
            planete3.SetActive(false);
            planete4.SetActive(true);

            Boss.SetActive(true);
            Earth.SetActive(true);

            if (Level4)
            {
                BossI.color = new Color(0, 255, 0,1);
            }
            else
            {
                BossI.color = new Color(255, 0, 0,1);
            }
            if (BOSS.Life <= 0 && !(LeBoss.active))
            {
                EarthI.color = new Color(0, 255, 0,1);
            }
            else
            {
                EarthI.color = new Color(255, 0, 0,1);
            }

        }
        else
        {
            Quest1.SetActive(false);
            Quest2.SetActive(false);
            Quest3.SetActive(false);
            Quest4.SetActive(false);

            planete1.SetActive(false);
            planete2.SetActive(false);
            planete3.SetActive(false);
            planete4.SetActive(false);

            claim1.SetActive(false);
            claim2.SetActive(false);
            claim3.SetActive(false);
            claim4.SetActive(false);

            Boss.SetActive(false);
            Earth.SetActive(false);
        }
    }

    public void SetQuestActive()
    {
        Quest1.SetActive(true);
        Quest2.SetActive(true);
        Quest3.SetActive(true);
        Quest4.SetActive(true);
    }

    public void SetClaimActive()
    {
        claim1.SetActive(true);
        claim2.SetActive(true);
        claim3.SetActive(true);
        claim4.SetActive(true);
    }

    public bool SetClaim(bool q1,bool q2,bool q3,bool q4)
    {
        if(q1)
        {
            im1.color = new Color(0, 255, 0,1);
        }
        else
        {
            im1.color = new Color(255, 0, 0,1);
        }
        if (q2)
        {
            im2.color = new Color(0, 255, 0,1);
        }
        else
        {
            im2.color = new Color(255, 0, 0,1);
        }
        if (q3)
        {
            im3.color = new Color(0, 255, 0,1);
        }
        else
        {
            im3.color = new Color(255, 0, 0,1);
        }
        if (q4)
        {
            im4.color = new Color(0, 255, 0,1);
        }
        else
        {
            im4.color = new Color(255, 0, 0,1);
        }
        return q1 && q2 && q3 && q4;
    }
}