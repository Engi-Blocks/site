using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MissionMenu : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject Boss;

    public GameObject claim1;
    public GameObject claim2;
    public GameObject claim3;
    public GameObject claim4;

    private Color red = new Color(255, 0, 0);
    private Color green = new Color(0, 255, 0,1);

    private bool l1_1 = true;
    private bool l1_2 = true;
    private bool l1_3 = true;
    private bool l1_4 = true;

    private bool l2_1 = true;
    private bool l2_2 = true;
    private bool l2_3 = true;
    private bool l2_4 = true;

    private bool l3_1 = true;
    private bool l3_2 = true;
    private bool l3_3 = true;
    private bool l3_4 = true;

    private bool l4_1 = true;
    private bool l4_2 = true;
    private bool l4_3 = true;
    private bool l4_4 = true;

    public static bool life = false;
    public void BossButton()
    {
        if (MissionMachine.Level4)
        {
            Boss.SetActive(true);
        }
    }

    void start()
    {
        life = false;
    }

    public void Earth()
    {
        if (BOSS.Life <= 0)
        {
            SceneManager.LoadScene("Credits");
        }
    }

    public void c1()
    {
        
        if (Carte1.level == LEVEL.LEVEL1 && l1_1)
        {
            HealPlayer(ref l1_1, 25);
        }
        else if (Carte1.level == LEVEL.LEVEL2 && l2_1)
        {
            l2_1 = false;
            InventoryShip.setCount(0, InventoryShip.getCount(0) + 10);
            HealPlayer(ref l3_1, 10);
        }
        else if (Carte1.level == LEVEL.LEVEL3 && l3_1)
        {
            l3_1 = false;
            InventoryShip.setCount(1, InventoryShip.getCount(1) + 10);
            HealPlayer(ref l3_1, 25);
        }
        else if (Carte1.level == LEVEL.LEVEL4 && l4_1)
        {
            l4_1 = false;
            InventoryShip.setCount(2, InventoryShip.getCount(2) + 10);
        }
    }

    public void c2()
    {

       
        if (Carte1.level == LEVEL.LEVEL1 && l1_2)
        {
            l1_2 = false;
            InventoryShip.setCount(2, InventoryShip.getCount(2) + 5);
        }
        else if (Carte1.level == LEVEL.LEVEL2 && l2_2)
        {
            l2_2 = false;
            InventoryShip.setCount(2, InventoryShip.getCount(2) + 5);
        }
        else if (Carte1.level == LEVEL.LEVEL3 && l3_2)
        {
            l3_2 = false;
            InventoryShip.setCount(0, InventoryShip.getCount(0) + 10);
        }
        else if (Carte1.level == LEVEL.LEVEL4 && l4_2)
        {
            l4_2 = false;
            InventoryShip.setCount(1, InventoryShip.getCount(1) + 10);
        }
    }

    public void c3()
    {

        if (Carte1.level == LEVEL.LEVEL1 && l1_3)
        {
            l1_3 = false;
            InventoryShip.setCount(1, InventoryShip.getCount(1) + 15);
        }
        else if (Carte1.level == LEVEL.LEVEL2 && l2_3)
        {
            l2_3 = false;
            HealPlayer(ref l1_3, 5);
        }
        else if (Carte1.level == LEVEL.LEVEL3 && l3_3)
        {
            l3_3 = false;
            InventoryShip.setCount(1, InventoryShip.getCount(1) + 10);
        }
        else if (Carte1.level == LEVEL.LEVEL4 && l4_3)
        {
            l4_3 = false;
            InventoryShip.setCount(2, InventoryShip.getCount(2) + 20);
        }
    }

    public void c4()
    {
        
        if (Carte1.level == LEVEL.LEVEL1 && l1_4)
        {
            l1_4 = false;
            InventoryShip.setCount(1, InventoryShip.getCount(1) + 10);
        }
        else if (Carte1.level == LEVEL.LEVEL2 && l2_4)
        {
            l2_4 = false;
            InventoryShip.setCount(5, InventoryShip.getCount(5) + 10);
        }
        else if (Carte1.level == LEVEL.LEVEL3 && l3_4)
        {
            l3_4 = false;
            InventoryShip.setCount(2, InventoryShip.getCount(2) + 10);
        }
        else if (Carte1.level == LEVEL.LEVEL4 && l4_4)
        {
            l4_4 = false;
            HealPlayer(ref l4_4, 100);
        }
    }

    public static void HealPlayer(ref bool condition,int vie)
    {
        condition = false;
        PlayerHealth.Heal = vie;
        life = true;
    }
}
