using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    // Start is called before the first frame update
    public static int damage;
    public Animator animator;
    public GameObject monster1;
    public GameObject monster2;
    public GameObject Player;
    float a;
    float b;
    public bool CanAttack1;
    public bool CanAttack2;
    public AudioClip ac;
    public AudioSource audioSource;

    void Start()
    {
        a = Time.time;
        b = Time.time;
        damage = 20;
    }

    // Update is called once per frame
    void Update()
    {
        CanAttack1 = (Abs(Player.transform.position.x - monster1.transform.position.x) <= 2) && (Abs(Player.transform.position.y - monster1.transform.position.y) <= 1.5);
        CanAttack2 = (Abs(Player.transform.position.x - monster2.transform.position.x) <= 2) && (Abs(Player.transform.position.y - monster2.transform.position.y) <= 1.5);
        if (CanAttack1)
        {
            float time = Time.time;
            if (Time.time - a >=1 && Input.GetKeyDown(KeyCode.P))
            {
                if (Minage.saber == Minage.SABER.YES)
                {
                    MoveMonster.GetDamage(40);
                }
                else
                {
                    MoveMonster.GetDamage(20);
                }
                if (monster1.transform.position.x >= Player.transform.position.x)
                {
                    if (monster1.active)
                    {
                        audioSource.PlayOneShot(ac, 3f);
                        if (Minage.saber == Minage.SABER.NO)
                        {
                            animator.Play("AttackRight");
                        }
                        else
                        {
                            animator.Play("SaberRight");
                        }
                    }
                }
                else
                {
                    if (monster1.active)
                    {
                        audioSource.PlayOneShot(ac, 3f);
                        if (Minage.saber == Minage.SABER.NO)
                        {
                            animator.Play("AttackLeft");
                        }
                        else
                        {
                            animator.Play("SaberLeft");
                        }
                    }
                }
                a = Time.time;
            }
            if (Time.time - time >= 1)
            {
                animator.Play("Basic");
            }
        }
        if (CanAttack2)
        {
            float time = Time.time;
            if (Time.time - b >= 1 && Input.GetKeyDown(KeyCode.P))
            {
                if (Minage.saber == Minage.SABER.YES)
                {
                    MoveMonster2.GetDamage(40);
                }
                else
                {
                    MoveMonster2.GetDamage(20);
                }
                if (monster2.transform.position.x >= Player.transform.position.x)
                {
                    if (monster2.active)
                    {
                        audioSource.PlayOneShot(ac, 3f);
                        if (Minage.saber == Minage.SABER.NO)
                        {
                            animator.Play("AttackRight");
                        }
                        else
                        {
                            animator.Play("SaberRight");
                        }
                    }
                }
                else
                {
                    if (monster2.active)
                    {
                        audioSource.PlayOneShot(ac, 3f);
                        if (Minage.saber == Minage.SABER.NO)
                        {
                            animator.Play("AttackLeft");
                        }
                        else
                        {
                            animator.Play("SaberLeft");
                        }
                    }
                }
                b = Time.time;
            }
            if (Time.time - time >= 1)
            {
                animator.Play("Basic");
            }
        }
       
    }

    public float Abs(float res)
    {
        if (res <= 0)
            return -res;
        else
            return res;
    }
}
