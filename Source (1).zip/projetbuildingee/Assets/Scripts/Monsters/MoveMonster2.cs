using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveMonster2 : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed = 1;
    private Transform posM;
    private GameObject Y;
    private GameObject Y2;
    public float y1;
    public float y2;
    public static float life;
    public int damage;
    public Animator animator;
    private float a;
    private int b;
    void Start()
    {
        damage = 10;
        Save.addSaveListener("Monster2",() =>
        {
            return (transform.position.x,transform.position.y,life,gameObject.activeSelf);
        }, o =>
        {
            (float x_, float y_,float life_,bool isActive_) = ((float,float,float,bool))o;
            gameObject.SetActive(isActive_);
            a = 0;
            b = 0;
            transform.position = new Vector3(x_, y_, 0); 
            life = life_;
            return false;
        },typeof((float,float,float,bool)),() =>
        {
            gameObject.SetActive(false);
            a = 0;
            b = 0;
            transform.position = new Vector3(-8f, -2f, 0); 
            life = 120;
        });
    }

    // Update is called once per frame
    void Update()
    {
        Y = GameObject.Find("perso_0");
        y1 = Y.transform.position.y;
        y2 = this.gameObject.transform.position.y;
        if (this.gameObject.transform.position.x > Y.transform.position.x)
        {
            transform.Translate(Vector3.left * speed * Time.deltaTime);
        }
        else
        {
            transform.Translate(Vector3.right * speed * Time.deltaTime);
        }
        if (y1<2 && y1>-2 && Abs(Y.transform.position.x) - Abs(this.gameObject.transform.position.x) < 2 && Abs(Y.transform.position.x) - Abs(this.gameObject.transform.position.x) > -2)
        {
            transform.position = new Vector3(this.gameObject.transform.position.x, this.gameObject.transform.position.y + 0.05f, 0);
        }
        if (life <= 0)
        {         
            transform.position = new Vector3(-8f, -2f, 0);
            a = a + 40;
            b = b + 3;
            life = 100 + a;
            damage = 7 + b;
            this.gameObject.SetActive(false);
        }
        jumpMonster();
    }

    public float Abs(float res)
    {
        if (res <= 0)
            return -res;
        else
            return res;
    }

    public void jumpMonster()
    {
        Y = GameObject.Find("perso_0");
        Y2 = GameObject.Find("monstre1_0");
        float yp = Y.transform.position.y;
        float xp = Y.transform.position.x;
        float y2 = this.gameObject.transform.position.y;
        float x2 = this.gameObject.transform.position.x;
        float y1 = Y2.transform.position.y;
        float x1 = Y2.transform.position.x;
        if (yp <0)
        {
            if (((xp>x2 && x1>x2) || (xp <x2 && x1<x2)) && (Abs(x1) - Abs(x2) < 1 && Abs(x1) - Abs(x2) > -1))
            {
                transform.position = new Vector3(this.gameObject.transform.position.x, this.gameObject.transform.position.y + 0.05f, 0);
            }
        }
    }

    public  void SetAttribute2(float _life,int _damage)
    {
        life = _life;
        damage = _damage;
    }

    public float Getlife2()
    {
        return life;
    }

    public int Getdamage2()
    {
        return damage;
    }

    public static void GetDamage(float damage)
    {
        life -= damage;
    }

}
