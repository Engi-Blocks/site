using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    public int Maxhealth = 100;
    public int currentHealth;
    public static int Heal=10;
    public float yplayer;
    public float xplayer;
    public float yMonster1;
    public float xMonster1;
    public float xMonster2;
    public float yMonster2;
    float a;
    float b;
    float c;
    public GameObject Y;
    public GameObject Y2;
    public GameObject Boss;

    public HealthBar healthBar;
    void Start()
    {
        currentHealth = Maxhealth;
        healthBar.SetMaxHealth(Maxhealth);
        c = Time.time;
    }
    
    void Update()
    {
        if (currentHealth <= 0)
        {
            SceneManager.LoadScene("mort");
        }

             
        xplayer = this.gameObject.transform.position.x;
        yplayer = this.gameObject.transform.position.y;
        xMonster1 = Y.gameObject.transform.position.x;
        yMonster1 = Y.gameObject.transform.position.y;
        xMonster2 = Y2.gameObject.transform.position.x;
        yMonster2 = Y2.gameObject.transform.position.y;
        if (Time.time - a >= 2)
        {
            if ((yplayer < 0 && yMonster1 < 0) || (yplayer > 0 && yMonster1 > 0))
            {
                if (Abs(xplayer) - Abs(xMonster1) < 1 && Abs(xplayer) - Abs(xMonster1) > -1)
                {
                    if (Y.active)
                    {
                        TakeDamage1(12);
                        
                    }
                }
            }
            a = Time.time;
        }
        if (Time.time - b >= 2 && ((yplayer < 0 && yMonster2 < 0) || (yplayer > 0 && yMonster2 > 0)))
        {           
            if (Abs(xplayer) - Abs(xMonster2) < 1.5 && Abs(xplayer) - Abs(xMonster2) > -1.5 )
            {
                if (Y2.active)
                {
                    TakeDamage1(10);
                    
                }
            }
            b = Time.time;
        }
        if (Abs(Boss.transform.position.x - this.transform.position.x) <= 2 && Boss.active && Time.time - c >= 4 && this.transform.position.y <2)
        {
            TakeDamage1(BOSS.Damage);
            
            c = Time.time;
        }
        if (MissionMenu.life)
        {
            
            MissionMenu.life = false;
            TakeDamage1(-Heal);
        }

    }

    public void TakeDamage1(int damage)
    {
        currentHealth -= damage;
        healthBar.SetHealth(currentHealth);
    }

    public float Abs(float res)
    {
        if (res <= 0)
            return -res;
        else
            return res;
              
    }

    
}
