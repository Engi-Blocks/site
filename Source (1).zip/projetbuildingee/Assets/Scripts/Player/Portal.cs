using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    // Start is called before the first frame update
    public Animator animator;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        GameObject X = GameObject.Find("perso_0");
        float x = X.transform.position.x;
        float y = X.transform.position.y;
        if (Input.GetKeyDown(KeyCode.U)  && x < 2 && x > -2)
        {
            animator.SetFloat("Activation", 8);
        }
        else
        {
            animator.SetFloat("Activation", 4);
        }
    }
}
