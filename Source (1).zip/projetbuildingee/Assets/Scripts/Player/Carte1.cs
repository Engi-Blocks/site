using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Carte1 : MonoBehaviour
{
    public static  bool cp1;
    public static  bool cp2;
    public static  bool cp3;
    public static  bool cp4;
    int id1;
    int id2;
    int id3;
    int id4;
    public GameObject monstre1;
    public GameObject monstre2;
    public static LEVEL level;

    public GameObject ImagePlanete1;
    public GameObject ImagePlanete2;
    public GameObject ImagePlanete3;
    public GameObject ImagePlanete0;
    public GameObject ImagePlaneteTerre;

    public GameObject BOSS;

    private Animation anim;
    public GameObject fenetre;

    void Start()
    {
        anim = gameObject.GetComponent<Animation>();

        cp1 = true;
        id1 = 0;
        id2 = 0;
        id3 = 0;
        id4 = 0;
        Save.addSaveListener("Level",() => (uint)level, o =>
        {
            level = (LEVEL) ((uint)o);
            ImagePlanete0.SetActive(level==LEVEL.LEVEL0);
            ImagePlanete1.SetActive(level==LEVEL.LEVEL1);
            ImagePlanete2.SetActive(level==LEVEL.LEVEL2);
            ImagePlanete3.SetActive(level==LEVEL.LEVEL3);
            ImagePlaneteTerre.SetActive(level==LEVEL.LEVEL4);
            cp1 = level == LEVEL.LEVEL0;
            return false;
        },typeof(uint), () =>
        {
            level = LEVEL.LEVEL0;
            cp1 = true;
            ImagePlanete0.SetActive(true);
            ImagePlanete1.SetActive(false);
            ImagePlanete2.SetActive(false);
            ImagePlanete3.SetActive(false);
            ImagePlaneteTerre.SetActive(false);
        });
    }
    public void p1()
    {              
        if (cp1)
        {
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp1 = false;
            level = LEVEL.LEVEL1;
            ImagePlanete0.SetActive(false);
            ImagePlanete1.SetActive(true);
            ImagePlanete2.SetActive(false);
            ImagePlanete3.SetActive(false);
            ImagePlaneteTerre.SetActive(false);
            fenetre.active = true;
            anim.Play("test");
        }
        else
        {

        }
    }

    public void p2()
    {
      
        if (cp2)
        {            
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp2 = false;
            level = LEVEL.LEVEL2;
            ImagePlanete1.SetActive(false);
            ImagePlanete2.SetActive(true);
            ImagePlanete3.SetActive(false);
            ImagePlaneteTerre.SetActive(false);
            fenetre.active = true;
            anim.Play("test");
        }
        else
        {

        }
    }

    public void p3()
    {
        
        if (cp3)
        {           
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp3 = false;
            level = LEVEL.LEVEL3;
            ImagePlanete1.SetActive(false);
            ImagePlanete2.SetActive(false);
            ImagePlanete3.SetActive(true);
            ImagePlaneteTerre.SetActive(false);
            fenetre.active = true;
            anim.Play("test");
        }
        else
        {

        }
    }

    public void Terre()
    {
        if (cp4)
        {
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp4 = false;
            level = LEVEL.LEVEL4;
            ImagePlanete1.SetActive(false);
            ImagePlanete2.SetActive(false);
            ImagePlanete3.SetActive(false);
            ImagePlaneteTerre.SetActive(true);
            fenetre.active = true;
            anim.Play("test");
        }
        else
        {

        }
    }

    public void Boss()
    {
        BOSS.SetActive(true);
        if (MissionMachine.Level4)
        {
            BOSS.SetActive(true);
        }
    }
}

public enum LEVEL
{
    LEVEL0,
    LEVEL1,
    LEVEL2,
    LEVEL3,
    LEVEL4,
}
