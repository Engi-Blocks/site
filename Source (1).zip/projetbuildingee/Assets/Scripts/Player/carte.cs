using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class carte : MonoBehaviour
{
    public GameObject perso_0Object;
    public float x;
    public bool Isin;
    public static int messageID;
    public Image Carte;
    public Text escape;
    public GameObject button1;
    public GameObject button2;
    public GameObject button3;
    public GameObject button4;

    public GameObject menuPause;
    public GameObject menuSave;
    public GameObject settings;

    void Start()
    {
        Carte = GameObject.FindGameObjectWithTag("carte").GetComponent<Image>();
        escape = GameObject.FindGameObjectWithTag("escape").GetComponent<Text>();
        messageID = 0;
        
    }
    void Update()
    {
        x = perso_0Object.transform.position.x;
        if (x > 14)
            Isin = true;
        else
            Isin = false;
        if (Isin && !escape.enabled)
        {
            Message.sendMessage("PRESS M TO OPEN THE MAP", ref messageID);
        }
        else
        {
            Message.clear(ref messageID);
        }
        if (Isin)
        {
            bool isKeyDownM = Input.GetKeyDown(KeyCode.M);
            if (Carte.enabled)
            {
                if (Input.GetKeyDown(KeyCode.Escape) || isKeyDownM)
                { 
                    Carte.enabled = false; 
                    escape.enabled = false;
                    button1.SetActive(false);
                    button2.SetActive(false);
                    button3.SetActive(false);
                    button4.SetActive(false);
                }
                if ((x > 14) == false)
                {
                    Carte.enabled = false;
                    escape.enabled = false;
                    button1.SetActive(false);
                    button2.SetActive(false);
                    button3.SetActive(false);
                    button4.SetActive(false);
                }
            }
            else
            {
                if (isKeyDownM && !menuPause.active && !menuSave.active && !settings.active)
                { 
                    Carte.enabled = true; 
                    Message.clear(ref messageID);
                    escape.enabled = true;
                    button1.SetActive(true);
                    button2.SetActive(true);
                    button3.SetActive(true);
                    button4.SetActive(true);
                }
            }
        }
        else
        {
            Carte.enabled = false;
            escape.enabled = false;
            button1.SetActive(false);
            button2.SetActive(false);
            button3.SetActive(false);
            button4.SetActive(false);
        }

    }
}
