using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Threading.Tasks;
using UnityEngine;
using Newtonsoft.Json;


public class Save
{
    private static Dictionary<string, (Func<object> saveEvent, Func<object, bool> loadEvent, Type type, Action newGame)> saveListener =
        new Dictionary<string, (Func<object>, Func<object, bool>, Type, Action newGame)>();

    private static List<Action<bool>> loadListener = new List<Action<bool>>();

    static readonly byte[] KEY_AES =
        {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16};

    private static JsonSerializerSettings serializerSettings = new JsonSerializerSettings();
    public static string pathDirectorySave = Application.persistentDataPath + "/save/";
    public static string lastNameFile = "";
    public const uint VERSION = 10;
    public const bool IS_CRYPT = false;

    public static Dictionary<string, Dictionary<string, object>> tempoSaves =
        new Dictionary<string, Dictionary<string, object>>();

    public static bool IsInGame = false;

    //                       key d'identification | obj à save      | si return true = erreur de load | type de l'obj à save
    public static void addSaveListener(string key, Func<object> save, Func<object, bool> load, Type typeSave, Action newGame=null)
    {
        saveListener[key] = (save, load, typeSave,newGame);
    }

    // si true = newGame si false = loadSave     <bool>  
    public static void addLoadGameListener(Action<bool> action)
    {
        loadListener.Add(action);
    }

//https://docs.microsoft.com/fr-fr/dotnet/standard/security/ensuring-data-integrity-with-hash-codes
//https://docs.microsoft.com/fr-fr/dotnet/standard/security/decrypting-data
    public static string getPathFileSave(string name)
    {
        return pathDirectorySave + name + ".engiblock";
    }

    public static void loadNewGame()
    {
        IsInGame = true;
        lastNameFile = "";
        foreach (var e in saveListener)
            if(e.Value.newGame!=null)e.Value.newGame();
        foreach (Action<bool> action in loadListener)
                    action(true);
    }

    public static Dictionary<string, Dictionary<string, object>> reloadSaves()
    {
        Debug.Log("Save location: "+pathDirectorySave);
        tempoSaves.Clear();
        if (Directory.Exists(pathDirectorySave))
            foreach (var path in Directory.GetFiles(pathDirectorySave, "*.engiblock"))
            {
                try
                {
                    string json = File.ReadAllText(path);
                    if (IS_CRYPT)
                    {
                        Debug.LogError("NON IMPLEMENTE");
                    }

                    (uint v, Dictionary<string, string> save) =
                        JsonConvert.DeserializeObject<(uint, Dictionary<string, string>)>(json);
                    if (v != VERSION)
                        throw new Exception("Antoine: Version de la save invalid");
                    Dictionary<string, object> saves = new Dictionary<string, object>();
                    foreach (var kv in saveListener)
                        if (save.ContainsKey(kv.Key))
                            saves.Add(kv.Key, JsonConvert.DeserializeObject(save[kv.Key], kv.Value.type));
                    saves.Add("change_at",File.GetLastWriteTime(path));
                    tempoSaves.Add(Path.GetFileNameWithoutExtension(path), saves);
                }
                catch (Exception e)
                {
                    Debug.LogWarning("Antoine: file save invalid path=" + path);
                    try
                    {
                        File.Delete(path);
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    }
                }
            }

        return tempoSaves;
    }

    public static async Task saveAndWrite(string name)
    {
        Dictionary<string, string> save = new Dictionary<string, string>();
        foreach (var kv in saveListener)
        {
            try
            {
                object ser = kv.Value.saveEvent();
                try
                {
                    save[kv.Key] = JsonConvert.SerializeObject(ser, kv.Value.type, serializerSettings);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
                //Debug.Log(JsonConvert.DeserializeObject(save[kv.Key]));
            }
            catch (Exception e)
            {
                Debug.LogError(e);
                Debug.LogError("Antoine: save serialisation impossible! key_for_save=" + kv.Key);
            }
        }

        string json = JsonConvert.SerializeObject((VERSION,save));
        if (IS_CRYPT)
        {
            try
            {
                MemoryStream myStream = new MemoryStream();
                StreamWriter writer = new StreamWriter(myStream);
                writer.Write(json);
                writer.Flush();
                myStream.Position = 0;
                using Aes aes = Aes.Create();
                aes.Key = KEY_AES;
                byte[] iv = aes.IV;
                myStream.Write(iv, 0, iv.Length);
                using CryptoStream cryptStream = new CryptoStream(
                    myStream,
                    aes.CreateEncryptor(),
                    CryptoStreamMode.Write);
                using (StreamReader srDecrypt = new StreamReader(cryptStream))
                {
                    json = srDecrypt.ReadToEnd();
                }
            }
            catch
            {
                Debug.LogError("Antoine: save write chiffrement impossible!");
            }
        }

        try
        {
            Directory.CreateDirectory(pathDirectorySave);
            using StreamWriter file = new StreamWriter(name, append: false);
            await file.WriteAsync(json);
            lastNameFile = Path.GetFileNameWithoutExtension(name);
        }
        catch (Exception e)
        {
            Debug.LogError("Antoine: save write file impossible! path=" + name);
        }
    }

    public static bool readAndLoad(string path)
    {
        try
        {
            string json = File.ReadAllText(path);
            if (IS_CRYPT)
            {
                Debug.LogError("NON IMPLEMENTE");
            }

            try
            {
                Dictionary<string, string> save = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                foreach (var kv in saveListener)
                {
                    if (save.ContainsKey(kv.Key))
                    {
                        try
                        {
                            object jsonObject = JsonConvert.DeserializeObject(save[kv.Key], kv.Value.type);
                            try
                            {
                                if (kv.Value.loadEvent(jsonObject))
                                    Debug.LogError("Antoine: read save loadGame error! key_for_save=" + kv.Key);
                            }
                            catch (Exception e)
                            {
                                Debug.LogError("Antoine: read save loadGame Exception! key_for_save=" + kv.Key);
                                Debug.LogError(e);
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Antoine: read save parsing json impossible! key_for_save=" + kv.Key);
                        }
                    }
                }

                lastNameFile = Path.GetFileNameWithoutExtension(path);
                foreach (Action<bool> action in loadListener)
                    action(false);
            }
            catch (Exception e)
            {
                Debug.LogError("Antoine: read save parsing json impossible!");
            }
        }
        catch (Exception e)
        {
            Debug.LogError("Antoine: read save imposible (file n'existe pas) path=" + path);
        }

        return false;
    }

    public static string debug()
    {
        string res = "";
        foreach (var path in Directory.GetFiles(pathDirectorySave, "*.engiblock"))
        {
            try
            {
                res += " <> " + File.ReadAllText(path);
            }
            catch (Exception e)
            {
            }
        }

        if (res.Length > 7000)
        {
            return res.Substring(0, 7000);
        }
        return res;
    }

    public static void load(string name)
    {
        Dictionary<string, object> select = tempoSaves[name];
        foreach (var e in saveListener)
            e.Value.loadEvent(select[e.Key]);
        lastNameFile = name;
        foreach (Action<bool> action in loadListener)
            action(false);
    }

    public static void clear()
    {
        saveListener = new Dictionary<string, (Func<object> saveEvent, Func<object, bool> loadEvent, Type type, Action newGame)>();
        loadListener = new List<Action<bool>>();
    }
}