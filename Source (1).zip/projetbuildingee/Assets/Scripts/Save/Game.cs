using System;
using UnityEngine;

public class Game : MonoBehaviour
{
    static public DateTime create_at;

    public void OnDestroy()
    {
        Save.clear();
    }

    void Start()
    {
        Save.addSaveListener("create_at",() => create_at,o =>
        { 
            create_at = (DateTime) o;
            return false;
        },typeof(DateTime));
        Save.addLoadGameListener(b =>
        {
            if (b) create_at = DateTime.Now;
        });
    }
}
