using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Energie : MonoBehaviour
{
    
    public Scrollbar bar;

    public Text powerText;

    public Text energieText;
    // Start is called before the first frame update
    public static Energie instance;

    public static int capacity
    {
        get;
        private set;
    }

    public static int energie
    {
        get;
        private set;
    }
    private static int power;

        public void Reset()
    {
        instance = this;
        
    }

    void Start()
    {
        instance = this;
        Save.addSaveListener("Energie",() => (energie,capacity), o =>
        {
            (int, int) e = ((int,int))o;
            energie = e.Item1;
            capacity = e.Item2;
            return false;
        },typeof((int,int)), () =>
        {
            energie = 9000;
            capacity = 10000;
        });
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public static int addEnergie(int addEnergie)//return le reste
    {
        power += addEnergie;
        if (energie + power < 0)
        {
            power -= energie + power;
            return energie + power;
        }

        if (energie + power > capacity)
        {
            power -= energie + power - capacity;
            return energie + power - capacity;
        }

        return 0;
    }

    public static bool isPossibleAddEnergie(int delta)
    {
        int test = power + delta + energie;
        return test >= 0 && test <= capacity;
    }

    public void _updateEnergie()
    {
        energie += power;
        if (power < 0)
        {
            powerText.text = power+"kW";
            powerText.color=Color.red;
        }
        else
        {
            powerText.text = "+"+power+"kW";
            powerText.color=Color.green;
        }

        energieText.text = energie + "/" + capacity;
        bar.size = energie / (float)capacity;
        power = 0;
    }

    public static void updateEnergie()
    {
        instance._updateEnergie();
    }
}
