using System;
using System.Collections.Generic;
using Items;
using UnityEngine;

public class InventoryShip : MonoBehaviour
{
    // Start is called before the first frame update
    public ItemData[] itemDatas;
    public static Dictionary<int, Item> items;
    public static Dictionary<int, ItemView> itemsViewBar;
    public static InventoryShip instance;
    public GameObject barItemsObject;
    public static List<Action<Item, int>> eventChangeCountItemsInventoryShip;

    private void OnDestroy()
    {
        items = new Dictionary<int, Item>();
        itemsViewBar = new Dictionary<int, ItemView>();
        eventChangeCountItemsInventoryShip = new List<Action<Item, int>>();
        instance = null;
    }

    private void Reset()
    {
        instance = this;
    }

    void Start()
    {
        items = new Dictionary<int, Item>();
        itemsViewBar = new Dictionary<int, ItemView>();
        eventChangeCountItemsInventoryShip = new List<Action<Item, int>>();
        instance = this;
        Save.addSaveListener("Items",saveGame,loadGame,typeof(Dictionary<int, int>));
        Save.addLoadGameListener((b =>{if(b)loadNewGame();} ));
        
    }

    public static ItemData getItemData(int id)
    {
        foreach (var i in instance.itemDatas)
        {
            if (i.id == id)
                return i;
        }

        return null;
    }

    public object saveGame()
    {
        Dictionary<int, int> counts = new Dictionary<int, int>();
        foreach (var kv in items)
            counts[kv.Key] = kv.Value.getCount();
        return counts;
    }

    public bool loadGame(object result)
    {
        loadNewGame();
        if (result is Dictionary<int, int>)
        {
            foreach (var kv in (Dictionary<int, int>) result)
            {
                if (items.ContainsKey(kv.Key))
                    items[kv.Key].setCount(kv.Value);
            }
            return false;
        }
        
        return true;
    }
    
    public static void addItem(Item item)
    {
        Item i = items[item.itemData.id];
        i.setCount(i.getCount()+item.getCount());
    }

    public void loadViewItems()
    {
        int i = 0;
        foreach (var item in items.Values)
        {
            ItemView itemView = item.addViewItem(barItemsObject);
            itemsViewBar[item.itemData.id] = itemView;
            itemView.createCanvas();
            itemView.rectItem.anchoredPosition = new Vector2(i * 80+15, 0f);
            itemView.rectItem.pivot = new Vector2(0f, 0.5f);
            itemView.rectItem.anchorMax = new Vector2(0f, 0.5f);
            itemView.rectItem.anchorMin = new Vector2(0f, 0.5f);
            i++;
            item.updateCountCanvas();
        }
    }

    public void loadNewGame()
    {
        eventChangeCountItemsInventoryShip=new List<Action<Item, int>>();
        itemDestroy();
        foreach (var itemData in itemDatas)
        {
            Item item = new Item(itemData);
            item.addEventListener(eventChangeCount);
            items[itemData.id] = item;
        }
        loadViewItems();
    }
    
    public void eventChangeCount(Item item, int lastCount)
    {
        foreach (var e in eventChangeCountItemsInventoryShip)
            e(item, lastCount);
    }

    public static void addEventInventoryChangeCount(Action<Item,int> action)
    {
        eventChangeCountItemsInventoryShip.Add(action);
    }

    public static int getCount(int id)
    {
        return items[id].getCount();
    }
    public static Item getItem(int id)
    {
        return items[id];
    }
    public static void addListenerEvent(int id,Action<Item,int> eventItem)
    {
        items[id].addEventListener(eventItem);
    }

    public static void setCount(int id, int n)
    {
        items[id].setCount(n);
    }

    public static bool isContain(int id, int n)
    {
        return items[id].isContain(n);
    }

    public static bool setCountDeltaSafe(int id, int delta)
    {
        return items[id].setCountDeltaSafe(delta);
    }

    public static void itemDestroy()
    {
        foreach (var item in items)
            item.Value.destroyViews();
        items.Clear();
        itemsViewBar.Clear();
    }
}