using UnityEngine;


public class GeneratorMachine : Machine
{
    public GeneratorMachine(MachineData machineData, object save = null) : base(machineData, save)
    {
    }

    public override void processeFinish()
    {
    }

    public override void startProssess(MachineData.recipe r)
    {
        foreach (var e in r.itemsInput)
            InventoryShip.setCountDeltaSafe(e.id, -e.getCount());
        gestionPanel.selectProssessPanel.decrem();
    }

    public override void energieInvalid(int power)
    {
    }
    
    public override void updateUI(bool isConsume)
    {
        gestionPanel.title.text = machineData.nameMachine;
        gestionPanel.power.text = "Power: " + (isConsume?getPower():0) + "kW";
        gestionPanel.scrollbar.setSize(recipe == -1?0f:processedTime / (float)machineData.recipes[recipe].time);
    }

    public override void update()
    {
        int power = getPower();
        if (Energie.isPossibleAddEnergie(power))
        {
            energieOk();
        }
        else
        {
            energieInvalid(power);
        }

        if (processedTime > 0)
        {
            inProcesse();
            processedTime--;
        }
        else if (recipe != -1)
        {
            processeFinish();
            recipe = -1;
        }
        else
        {
            noProcesse();
        }

        Energie.addEnergie(power);
        updateUI(true);
    }

    public override void inProcesse()
    {
        setMsgPanel(processedTime + " Seconds of Fuel Left", Color.blue);
    }
}