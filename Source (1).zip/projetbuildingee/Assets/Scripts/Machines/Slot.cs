using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Machines
{
    public class Slot : MonoBehaviour
    {
        public bool isInput;
        private ItemData[] itemDatas;
        private Item item;
        private ItemView itemView;
        private GameObject parentObject;
        private GameObject buttonObject;
        private RectTransform parentRect;
        private RectTransform buttonRect;
        private Button button;
        private static Slot menuOpen;
        private GameObject menuObject;
        private GameObject contentMenuObject;
        private RectTransform contentMenuRect;
        private ItemView[] menuItemViews;
        public bool isInteractable = true;
        public static GameObject prefabMenu;
        public List<Action<Slot>> onClickSlotActions = new List<Action<Slot>>();

        public void init(ItemData[] itemDatas = null)
        {
            if (prefabMenu == null)
                prefabMenu = Resources.Load<GameObject>("Prefabs/Slot/menu");
            onClickSlotActions = new List<Action<Slot>>();
            this.itemDatas = itemDatas;
            Vector2 pos = new Vector2(0, 0);
            parentObject = new GameObject("Slot");
            buttonObject = new GameObject("OnClick");
            parentRect = parentObject.AddComponent<RectTransform>();
            parentRect.SetParent(gameObject.transform);
            parentRect.anchoredPosition = pos;
            parentRect.sizeDelta = new Vector2(32f, 32f);
            parentRect.anchorMax = new Vector2(0.5f, 0.5f);
            parentRect.anchorMin = new Vector2(0.5f, 0.5f);
            parentRect.pivot = new Vector2(0.5f, 0.5f);
            if (isInput)
            {
                menuObject = Instantiate(prefabMenu, parentRect);
                menuObject.SetActive(false);
                contentMenuRect = menuObject.transform.GetChild(0).GetChild(0).GetComponent<RectTransform>();
                int i = 0;
                menuItemViews = new ItemView[itemDatas.Length];
                foreach (var data in itemDatas)
                {
                    ItemView itemV = InventoryShip.getItem(data.id).addViewItem(contentMenuRect.gameObject);
                    itemV.createCanvas();
                    itemV.updateCountCanvas();
                    itemV.initOnClick().AddListener((() => { onClickItemMenu(itemV); }));
                    itemV.rectItem.anchoredPosition = new Vector2(0f, -50f * i);
                    itemV.rectItem.pivot = new Vector2(0.5f, 1f);
                    itemV.rectItem.anchorMax = new Vector2(0.5f, 1f);
                    itemV.rectItem.anchorMin = new Vector2(0.5f, 1f);
                    itemV.objectNameText.SetActive(false);
                    menuItemViews[i] = itemV;
                    i++;
                }

                contentMenuRect.sizeDelta = new Vector2(0, i == 0 ? 150 : i * 50);
            }

            button = buttonObject.AddComponent<Button>();
            buttonRect = buttonObject.AddComponent<RectTransform>();
            buttonRect.SetParent(parentRect);
            buttonRect.anchoredPosition = new Vector2();
            buttonRect.sizeDelta = new Vector2(32f, 32f);
            buttonRect.anchorMax = new Vector2(0f, 1f);
            buttonRect.anchorMin = new Vector2(0f, 1f);
            buttonRect.pivot = new Vector2(0f, 1f);
            Navigation navigation = new Navigation();
            navigation.mode = Navigation.Mode.None;
            button.navigation = navigation;
            button.transition = Selectable.Transition.None;
            Image image = buttonObject.AddComponent<Image>();
            image.color = new Color(0f, 0f, 0f, 0f);
            button.onClick.AddListener(onclickSlot);
        }

        public void onClickItemMenu(ItemView itemV)
        {
            setSelectItems(itemV.itemData);
            hideMenu();
        }

        public bool isSetValidOutput(int id)
        {
            return item == null || item.id == id;
        }

        public void addActionOnclick(Action<Slot> action)
        {
            onClickSlotActions.Add(action);
        }

        public void addOuput(int id, int count, bool force = false)
        {
            if (force || item == null || item.id != id)
            {
                item = new Item(InventoryShip.getItem(id).itemData, (uint) count);
                createCanvas(item);
                itemView.setIndexParent(-2);
            }
            else
            {
                item.setCountDeltaSafe(count);
            }
        }

        private void onclickSlot()
        {
            if (isInteractable)
            {
                if (isInput)
                {
                    if (menuObject.activeSelf)
                        hideMenu();
                    else
                        showMenu();
                }
                else
                {
                    recoverItem();
                }
            }

            foreach (var action in onClickSlotActions)
                action(this);
        }

        public void showSlot()
        {
            parentObject.SetActive(true);
        }

        public void hideSlot()
        {
            parentObject.SetActive(false);
            hideMenu();
        }

        public void showMenu()
        {
            if (isInput)
            {
                if (menuOpen != null)
                    menuOpen.hideMenu();
                menuOpen = this;
                menuObject.SetActive(true);
            }
        }

        public void hideMenu()
        {
            if (isInput)
            {
                if (menuOpen == this)
                    menuOpen = null;
                menuObject.SetActive(false);
            }
        }

        private void createCanvas(Item item)
        {
            itemView = item.addViewItem(parentObject);
            itemView.createCanvas();
            itemView.updateCountCanvas();
            itemView.rectItem.anchoredPosition = new Vector2(0f, 0f);
            itemView.rectItem.pivot = new Vector2(0f, 1f);
            itemView.rectItem.anchorMax = new Vector2(0f, 1f);
            itemView.rectItem.anchorMin = new Vector2(0f, 1f);
            itemView.objectNameText.SetActive(false);
            itemView.countText.color = Color.black;
            itemView.rectCount.anchoredPosition = new Vector2(10f,0f);
        }

        public void setSelectItems(ItemData select)
        {
            if (itemView == null || itemView.itemData.id != select.id)
            {
                if (itemView != null)
                    itemView.removeCanvas();
                createCanvas(InventoryShip.getItem(select.id));
                itemView.setIndexParent(-2);
            }
        }

        public Item getOutputItem()
        {
            return item;
        }

        public Item getItemInventoryShipSelect()
        {
            return itemView == null ? null : itemView.item;
        }

        public void clearOutputItem()
        {
            if (item != null)
            {
                item.destroyViews();
                item = null;
            }
        }

        public void recoverItem()
        {
            if (item != null)
            {
                InventoryShip.addItem(item);
                item.destroyViews();
                item = null;
            }
        }
    }
}