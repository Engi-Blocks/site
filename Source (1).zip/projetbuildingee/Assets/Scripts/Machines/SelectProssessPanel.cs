using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectProssessPanel : MonoBehaviour
{
    public Button up;
    public Button down;
    public Text text;

    private int count;
    
    void Start()
    {
            up.onClick.AddListener((() =>
            {
                count++;
                updateCount();
            }));
            down.onClick.AddListener(decrem);
            updateCount();
    }

    public void updateCount()
    {
        text.text = count+"";
    }

    public int getCount()
    {
        return count;
    }

    public SelectProssessPanel setCount(int v)
    {
        if (v < 0)
            v = 0;
        if (v > 99)
            v = 99;
        if (v != count)
        {
            count = v;
            updateCount();
        }
            
        return this;
    }

    public void decrem()
    {
        setCount(count - 1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
