using System;
using System.Collections;
using System.Collections.Generic;
using Machines;
using UnityEngine;
using UnityEngine.UI;

public class Machine
{
    public int level;
    //public int health; non implémenté
    public int recipe=-1;//si -1 pas de recipe
    public int processedTime;//si 0 process finish
    public MachineData machineData;
    public GameObject machineObject;
    public GameObject panelObject;
    public GestionPanel gestionPanel;
    public static Machine isOpen;
    private object saveTempo;
    
    //https://docs.unity3d.com/ScriptReference/MonoBehaviour.OnMouseDown.html
    public Machine(MachineData machineData, object save = null)
    {
        this.machineData = machineData;
        saveTempo = save;
    }

    public void init()
    {
        machineObject = new GameObject("Machine " + this.machineData.nameMachine);
        machineObject.transform.SetParent(MachineGame.instance.gameObject.transform);
        machineObject.transform.position = machineData.posMachine;
        machineObject.transform.localScale = machineData.scaleMachine;
        SpriteRenderer spriteRenderer = machineObject.AddComponent<SpriteRenderer>();
        spriteRenderer.sprite = machineData.spriteMachine;
        spriteRenderer.sortingOrder = 2;
        machineObject.AddComponent<BoxCollider>();
        machineObject.AddComponent<MachineSprite>().onclic = onClicSprite;
        panelObject = GameObject.Instantiate(machineData.panelObject,MachineGame.instance.panelParent.transform);
        gestionPanel = panelObject.GetComponent<GestionPanel>();
        updateUI(false);
        panelObject.SetActive(false);
        if(gestionPanel.OuputSlot!=null)
            gestionPanel.OuputSlot.init();
        List<ItemData> total = new List<ItemData>();
        foreach (var r in machineData.recipes)
            foreach (var i in r.itemsInput)
                if(!total.Contains(i.itemData))
                    total.Add(i.itemData);
        ItemData[] tt = total.ToArray();
        total.Clear();
        foreach (var s in gestionPanel.InputSlots)
            s.init(tt);
        foreach (var v in gestionPanel.levelSlots)
        {
            v.init();
            v.addActionOnclick(onClicNextLevel);
        }

        if (saveTempo != null)
        {
            load(saveTempo);
        }
        updateLevelUI();
        setMsgPanel("Waiting");
        saveTempo = null;
    }

    private void load(object save)
    {
        (int rec,int time,int lev, int id, int count, int nProssess, object ext) = ((int,int,int,int,int,int,object))save;
        recipe = rec;
        processedTime = time;
        level = lev;
        gestionPanel.selectProssessPanel.setCount(nProssess);
        if (recipe >= 0)
        {
            Item[] inputs = machineData.recipes[recipe].itemsInput;
            for (int i = 0; i < inputs.Length; i++)
                gestionPanel.InputSlots[i].setSelectItems(inputs[i].itemData);
        }
        if(id>=0 && gestionPanel.OuputSlot!=null)
            gestionPanel.OuputSlot.addOuput(id,count,true);
        loadExt(ext);
    }

    public void loadExt(object save)
    {
        
    }

    public Type getTypeSaveExt()
    {
        return null;
    }

    public object saveExt()
    {
        return null;
    }

    public (int rec,int time,int lev,int id,int count, int nProssess,object ext) save()
    {
        Item outputItem = gestionPanel.OuputSlot!=null?gestionPanel.OuputSlot.getOutputItem():null;
        return (recipe,processedTime,level,outputItem==null?-1:outputItem.id,outputItem==null?-1:outputItem.getCount(),gestionPanel.selectProssessPanel.getCount(),saveExt());
    }

    public Type getTypeSave()
    {
        return typeof((int rec,int time,int lev,int id,int count, int nProssess,object ext));
    }

    public void updateLevelUI()
    {
        gestionPanel.level.text = "Level: "+level;
        foreach (var v in gestionPanel.levelSlots)
            v.clearOutputItem();
        if (level < machineData.levels.Length - 1)
        {
            var levelUp = machineData.levels[level + 1];
            int i = 0;
            foreach (var v in levelUp.itemsForLevel)
            {
                gestionPanel.levelSlots[i].addOuput(v.id,v.getCount(),true);
                i++;
            }
        }
    }

    public void onClicNextLevel(Slot slot)
    {
        if (level < machineData.levels.Length - 1)
        {
            var levelUp = machineData.levels[level + 1];
            if (Energie.isPossibleAddEnergie(levelUp.energyForLevel))
            {
                int i = 0;
                while (i<levelUp.itemsForLevel.Length && InventoryShip.isContain(levelUp.itemsForLevel[i].id,levelUp.itemsForLevel[i].getCount()))
                {
                    i++;
                }

                if (i == levelUp.itemsForLevel.Length)
                {
                    foreach (var e in levelUp.itemsForLevel)
                    {
                        InventoryShip.setCountDeltaSafe(e.id, -e.getCount());
                    }
                    Energie.addEnergie(levelUp.energyForLevel);
                    level++;
                    updateLevelUI();
                }
                else
                {
                    setMsgPanel("Item missing !",Color.red);
                }
            }
            else
            {
                setMsgPanel("Energie missing ! (require "+levelUp.energyForLevel+"kJ)",Color.red);
            }
        }
    }

    public virtual void updateUI(bool isConsume)
    {
        gestionPanel.title.text = machineData.nameMachine;
        gestionPanel.power.text = "Power: " + (isConsume?getPower():0) + "kW";
        gestionPanel.scrollbar.setSize(recipe == -1?0f:(machineData.recipes[recipe].time - processedTime) / (float)machineData.recipes[recipe].time);
    }

    public void setMsgPanel(string msg,Color? color=null)
    {
        gestionPanel.prossess.text = msg;
        if(color==null)
            color=Color.black;
        gestionPanel.prossess.color = (Color)color;
    }

    public void onClicSprite()
    {
        if(isOpen==null)
            showPanel();
    }

    public static bool isPanelOpen()
    {
        return isOpen != null;
    }

    public void showPanel()
    {
        if(isOpen != null)
            isOpen.hidePanel();
        isOpen = this;
        panelObject.SetActive(true);
    }

    public void hidePanel()
    {
        if (this == isOpen)
            isOpen = null;
        panelObject.SetActive(false);
    }

    public void destroy()
    {
        GameObject.Destroy(machineObject);
        GameObject.Destroy(panelObject);
    }

    public virtual void update()
    {
        int power = getPower();
        if (Energie.isPossibleAddEnergie(power))
        {
            energieOk();
            if (processedTime > 0)
            {
                inProcesse();
                processedTime--;
            }
            else if (recipe != -1)
            {
                processeFinish();
                recipe = -1;
            }
            else
            {
                noProcesse();
            }

            Energie.addEnergie(power);
            updateUI(true);
        }
        else
        {
            energieInvalid(power);
            updateUI(false);
        }
    }

    public virtual void energieOk()
    {
    }

    public virtual void energieInvalid(int power)
    {
        setMsgPanel("Power missing {require "+getPower()+"kW}",Color.red);
    }

    public virtual void inProcesse()
    {
        setMsgPanel("Processing in progress, remaining time "+processedTime+"s",Color.blue);
        if (!isValidProssess())
        {
            recipe = -1;
            processedTime = 1;
        }
    }

    public virtual bool isValidProssess(MachineData.recipe r=null)
    {
        if (r == null)
        {
            if(gestionPanel.selectProssessPanel.getCount()==0)
                return false;
            r=machineData.recipes[recipe];
        }
        foreach (var e in r.itemsInput)
            if(!InventoryShip.isContain(e.id,e.getCount()))
                return false;
        return true;
    }

    public virtual void processeFinish()
    {
        setMsgPanel("Finished processing !",Color.green);
        var r = machineData.recipes[recipe];
        if (isValidProssess())
        {
            foreach (var e in r.itemsInput)
                InventoryShip.setCountDeltaSafe(e.id, -e.getCount());
            gestionPanel.OuputSlot.addOuput(r.itemOutput.id,r.itemOutput.getCount());  
            gestionPanel.selectProssessPanel.decrem();
        }
        
    }

    public virtual void noProcesse()
    {
        setMsgPanel("Waiting");
        if(gestionPanel.selectProssessPanel.getCount()==0)
            return;
        var recipes = machineData.recipes;
        for (int i = recipes.Length-1; i >= 0; i--)
        {
            var r = recipes[i];
            if (r.requireLevel <= level &&
                (gestionPanel.OuputSlot == null || gestionPanel.OuputSlot.getOutputItem() == null ||
                 r.itemOutput.isEqualType(gestionPanel.OuputSlot.getOutputItem())) && isValidProssess(r))
            {
                foreach (var de in r.itemsInput)
                {
                    uint y = 0;
                    while (y < gestionPanel.InputSlots.Length && !de.isEqualType(gestionPanel.InputSlots[y].getItemInventoryShipSelect()))
                        y++;
                    if (y != gestionPanel.InputSlots.Length)
                    {
                        recipe = i;
                        processedTime = r.time;
                        startProssess(r);
                        return;
                    }
                }
            }
        }
    }

    public virtual void startProssess(MachineData.recipe recipe)
    {
        
    }

    public virtual void playerGetItemSlotOutput(Slot slot)//event
    {
        throw new NotImplementedException();
    }

    public virtual void playerSelecteItemSlotInput(Slot slot)//event
    {
        throw new NotImplementedException();
    }

    public int getPower()
    {
        return recipe == -1?machineData.levels[level].powerPasif:machineData.recipes[recipe].powerActif;
    }
    
}
