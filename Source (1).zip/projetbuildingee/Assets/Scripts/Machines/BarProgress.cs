using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarProgress : MonoBehaviour
{
    public float sizeMax;
    public float other;
    public bool isHorizontal = true;
    public RectTransform color;
    void Start()
    {
        if (isHorizontal)
        {
            color.sizeDelta=new Vector2(0f,other);
        }
        else
        {
            color.sizeDelta=new Vector2(other,0f);
        }
    }

    public void setSize(float rapport)
    {
        if (isHorizontal)
        {
            color.sizeDelta=new Vector2(sizeMax*rapport,other);
        }
        else
        {
            color.sizeDelta=new Vector2(other,sizeMax*rapport);
        }
    }
    

}
