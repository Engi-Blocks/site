using System.Collections;
using System.Collections.Generic;
using Machines;
using UnityEngine;
using UnityEngine.UI;

public class GestionPanel : MonoBehaviour
{
    public Text title;
    public Text level;
    public Text prossess;
    public BarProgress scrollbar;
    public Text power;
    public SelectProssessPanel selectProssessPanel;
    public Slot[] InputSlots;
    public Slot OuputSlot;
    public Slot[] levelSlots;
}
