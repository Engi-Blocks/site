using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using UnityEngine;

[CreateAssetMenu(fileName="MachineData", menuName="My Game/Machine/Machine")]
public class MachineData : ScriptableObject
{
    public uint idMachine;
    public ItemData machineItem;
    public Level[] levels;
    public recipe[] recipes;
    public string nameMachine;
    public string descriptionMachine;
    
    public Sprite spriteMachine;
    public Vector2 posMachine;
    public Vector2 scaleMachine;

    public string typeClass;
    
    public GameObject panelObject;

    [Serializable]
    public class Level
    {
        public Item[] itemsForLevel;
        public int energyForLevel;
        public int powerPasif;
    }
    [Serializable]
    public class recipe
    {
        public Item[] itemsInput;
        public Item itemOutput;
        public int powerActif;
        public int time;//en seconde
        public int requireLevel;
    }
}
