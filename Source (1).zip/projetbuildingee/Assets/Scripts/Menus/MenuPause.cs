using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Button = UnityEngine.UIElements.Button;

public class MenuPause : MonoBehaviour
{
    public GameObject settingsWindow;
    public GameObject menu;
    public GameObject saveButton;
    public InputField inputNameFileSave;
    public Image mapIU;
    private static MenuPause instance;
    public GameObject perso;
    public GameObject menuSave;
    public GameObject transition;

    void Start()
    {
        instance = this;
    }

    public static bool getIsPause()
    {
        return instance.menu.activeSelf;
    }

    public void filterInput()
    {
        inputNameFileSave.text=getNameFormated();
    }
    public string getNameFormated()
    {
        string name = "";
                foreach (char c in inputNameFileSave.text)
                {
                    if ((c < 123 && c > 96) || (c < 91 && c > 64) || (c < 58 && c > 47) || c == 32 || c==95)
                    {
                        name += c;
                        if(name.Length > 32)
                            break;
                    }
                }

                return name;
    }

    public void loadLastSave()
    {
        SaveMenuElement.openUI();
        menu.SetActive(false);
    }

    public void buttonSaveOnclick()
    {
        string name = getNameFormated();
        if(name.Length==0)
            return;
        Save.saveAndWrite(Save.getPathFileSave(name));
    }

    public void MenuLeaveWithoutSave()
    {
        SceneManager.LoadScene("MenuPrincipal");
    }
    
    public void MenuLeaveAndSave()
    {
        buttonSaveOnclick();
        SceneManager.LoadScene("MenuPrincipal");
    }

    public void OpenSettingsWindow()
    {
        settingsWindow.SetActive(true);
        menu.SetActive(false);
    }
    
    public void CloseSettingsWindow()
    {
        settingsWindow.SetActive(false);
        menu.SetActive(true);
    }

    public void CloseMenu()
    {
        menu.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && !mapIU.enabled && !settingsWindow.active && !menuSave.active && !Machine.isPanelOpen() && !transition.active)
        {
            menu.SetActive(!menu.activeSelf);
            if (menu.activeSelf)
            {
                inputNameFileSave.text = Save.lastNameFile;
            }
        }
        if (menuSave.active || menu.active || settingsWindow.active)
        {
            Time.timeScale = 0;
            perso.GetComponent<MOVE>().enabled = false;
        }
        else
        {
            Time.timeScale = 1;
            perso.GetComponent<MOVE>().enabled = true;
        }
    }
}
