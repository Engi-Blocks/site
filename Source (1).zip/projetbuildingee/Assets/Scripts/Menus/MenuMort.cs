using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;

public class MenuMort : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject Menu;
    public GameObject Quit;
    void Start()
    {
    }

    public void MenuP()
    {
        SceneManager.LoadScene("MenuPrincipal");
    }

    public void quit()
    {
        Application.Quit();
    }

}
