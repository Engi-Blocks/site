using UnityEngine;

public class MenuSave : MonoBehaviour
{
    public Sprite backgroundSprite;
    public GameObject[] saveSelectObjects;
    public bool st1 = true;

    //public GameObject scrollObject;
    // Start is called before the first frame update
    void Start()
    {
        SaveMenuElement.start(backgroundSprite, saveSelectObjects);
    }

    void Start1()
    {
        SaveMenuElement.update();
    }

    // Update is called once per frame
    void Update()
    {
        if (st1)
        {
            Start1();
            st1 = false;
        }
    }

    public void buttonDelete()
    {
        SaveMenuElement.deleteButton();
    }

    public void buttonSaveOver()
    {
        SaveMenuElement.saveOverButton();
    }

    public void buttonLoad()
    {
        SaveMenuElement.loadButton();
    }

    public void buttonNewGame()
    {
        Save.loadNewGame();
        SaveMenuElement.closeUI();
    }
}
