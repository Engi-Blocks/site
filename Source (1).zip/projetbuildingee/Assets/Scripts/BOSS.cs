using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BOSS : MonoBehaviour
{
    // Start is called before the first frame update
    public static int Life = 500;
    public static int Damage;
    public GameObject Player;
    private float speed;
    float a;
    public Animator animator;
    void Start()
    {
        Life = 400;
        Damage = 25;
        speed = 2;
        a = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        if (this.transform.position.x < Player.transform.position.x)
        {
            transform.Translate(Vector3.right * speed * Time.deltaTime);
        }
        else
        {
            transform.Translate(Vector3.left * speed * Time.deltaTime);
        }
        if (Life<=0)
        {
            this.gameObject.SetActive(false);
        }
        if (Abs(Player.transform.position.x - this.transform.position.x) <= 3 && Time.time -a >=1 && Input.GetKeyDown(KeyCode.P) && this.gameObject.active)
        {
            if (Minage.saber == Minage.SABER.YES)
            {
                TakeDamageBoss(40);
            }
            else
            {
                TakeDamageBoss(20);
            }
            a = Time.time;
            if (this.transform.position.x < Player.transform.position.x)
            {
                if (Minage.saber == Minage.SABER.NO)
                {
                    animator.Play("AttackLeft");
                }
                else
                {
                    animator.Play("SaberLeft");
                }
            }
            else
            {
                if (Minage.saber == Minage.SABER.NO)
                {
                    animator.Play("AttackRight");
                }
                else
                {
                    animator.Play("SaberRight");
                }
            }
        }
    }

    public void TakeDamageBoss(int Damage)
    {
        Life -= Damage;
    }

    public enum BOSSyn
    {
        IsSpawn,
        not,
    }

    public float Abs(float res)
    {
        if (res <= 0)
            return -res;
        else
            return res;

    }


}
