using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Message : MonoBehaviour
{
    private static GameObject _gameObject;
    private static Text text;
    private static int id;
    void Start()
    {
        text=gameObject.GetComponent<Text>();
        _gameObject = gameObject;
    }

    public static void sendMessage(string message, ref int testId)//return l'id pour le clear
    {
        if (testId == 0)
        {
            if (text != null)
            {
                text.text = message;
                text.enabled = true;
            }
            id++;
            testId = id;
        }
    }

    //si id == -1 clear le message dans tous les cas
    public static void clear(ref int _id)//l'id est utilisée pour éviter de clear le message d'une autre partie du code
    {
        if (text != null && id == _id)
        {
            text.text = "";
            text.enabled=false;
        }
        _id = 0;
    }
    
    public static void clear()
    {
        text.text = "";
        text.enabled=false;
    }
}
