using UnityEngine;
using UnityEngine.SceneManagement;

public class animation : MonoBehaviour
{
    public Scene currentScene;

    public void loadAnimation()
    {
        SceneManager.LoadScene("SampleScene");
    }
}
