using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Minage : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject player;
    private float XPlayer;
    private float YPlayer;

    private int id0;
    private int id1;
    private int id2;
    private int id3;
    private int id4;

    private int IronLvl1 = 30;
    private int UraniumLvl1 = 0;
    private int CopperLvl1 = 30;
    private int StoneLvl1 = 30;

    private int IronLvl2 = 40;
    private int UraniumLvl2 = 20;
    private int CopperLvl2 = 30;
    private int StoneLvl2 = 30;

    private int IronLvl3 = 40;
    private int UraniumLvl3 = 20;
    private int CopperLvl3 = 40;
    private int StoneLvl3 = 30;

    private int IronLvl4 = 30;
    private int UraniumLvl4 = 30;
    private int CopperLvl4 = 30;
    private int StoneLvl4 = 30;

    private float timeMine;
    private float timeMessage;

    public Animator animator;

    public AudioClip ac;
    public AudioSource audioSource;

    public GameObject perso;

    public static SABER saber;

    private bool res = true;

    void Start()
    {
        id0 = 0;
        id1 = 0;
        id2 = 0;
        id3 = 0;
        id4 = 0;
        timeMine = Time.time;
        timeMessage = Time.time;
        saber = SABER.NO;
        Save.addSaveListener("Mining", () =>
        {
            return saber;
        }, o =>
        {
            saber = (SABER) o;
            return false;
            
        }, typeof(SABER), ()=>saber = SABER.NO);
        Save.addLoadGameListener(b =>
        {
            res = saber == SABER.NO;
        });
        res = true;
    }

    bool AnimatorIsPlaying()
    {
        return animator.GetCurrentAnimatorStateInfo(0).length >
               animator.GetCurrentAnimatorStateInfo(0).normalizedTime;
    }

    bool AnimatorIsPlaying(string stateName)
    {
        return AnimatorIsPlaying() && animator.GetCurrentAnimatorStateInfo(0).IsName(stateName);
    }

    // Update is called once per frame
    void Update()
    {
        XPlayer = player.transform.position.x;
        YPlayer = player.transform.position.y;
        if (XPlayer >=2.75f && YPlayer> 2.75f && Carte1.level != LEVEL.LEVEL0)
        {
            Message.sendMessage("Press B to mine", ref id0);
            if (Input.GetKeyDown(KeyCode.B) && Time.time - timeMine >= 1)
            {              
                Mine();
                audioSource.PlayOneShot(ac);
                animator.Play("MineWithPickaxe");
                timeMine = Time.time;               
            }
            if (Time.time - timeMessage >= 1)
            {
                timeMessage = Time.time;
                Message.clear(ref id1);
                Message.clear(ref id2);
                Message.clear(ref id3);
                Message.clear(ref id4);
            }
            Message.sendMessage("Press B to mine", ref id0);
        }       
        else
        {
            Message.clear(ref id0);
        }

        if (AnimatorIsPlaying("MineWithPickaxe"))
        {
            perso.GetComponent<MOVE>().enabled = false;
        }
        else
            perso.GetComponent<MOVE>().enabled = true;
    }

    public void Mine()
    {
        int random = Random.Range(0, 200);
        if (random >=0 && random <= 50)
        {
            if (Carte1.level == LEVEL.LEVEL1 && CopperLvl1 > 0)
            {
                InventoryShip.setCount(4, InventoryShip.getCount(4) + 1);
                Message.sendMessage("Copper Ore x 1", ref id1);
                CopperLvl1 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL2 && CopperLvl2 > 0)
            {
                InventoryShip.setCount(4, InventoryShip.getCount(4) + 1);
                Message.sendMessage("Copper Ore x 1", ref id1);
                CopperLvl2 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL3 && CopperLvl3 > 0)
            {
                InventoryShip.setCount(4, InventoryShip.getCount(4) + 1);
                Message.sendMessage("Copper Ore x 1", ref id1);
                CopperLvl3 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL4 && CopperLvl4 > 0)
            {
                InventoryShip.setCount(4, InventoryShip.getCount(4) + 1);
                Message.sendMessage("Copper Ore x 1", ref id1);
                CopperLvl4 -= 1;
            }
        }
        else if (random > 50 && random <= 90)
        {
            if (Carte1.level == LEVEL.LEVEL1 && IronLvl1 > 0)
            {
                InventoryShip.setCount(3, InventoryShip.getCount(3) + 1);
                Message.sendMessage("Iron Ore x 1", ref id2);
                IronLvl1 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL2 && IronLvl2 > 0)
            {
                InventoryShip.setCount(3, InventoryShip.getCount(3) + 1);
                Message.sendMessage("Iron Ore x 1", ref id2);
                IronLvl2 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL3 && IronLvl3 > 0)
            {
                InventoryShip.setCount(3, InventoryShip.getCount(3) + 1);
                Message.sendMessage("Iron Ore x 1", ref id2);
                IronLvl3 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL4 && IronLvl4 > 0)
            {
                InventoryShip.setCount(3, InventoryShip.getCount(3) + 1);
                Message.sendMessage("Iron Ore x 1", ref id2);
                IronLvl4 -= 1;
            }
        }
        else if (random > 90 && random <= 100)
        {

            if (Carte1.level == LEVEL.LEVEL1 && UraniumLvl1 > 0)
            {
                InventoryShip.setCount(5, InventoryShip.getCount(5) + 1);
                Message.sendMessage("Uranium Ore x 1", ref id3);
                UraniumLvl1 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL2 && UraniumLvl2 > 0)
            {
                InventoryShip.setCount(5, InventoryShip.getCount(5) + 1);
                Message.sendMessage("Uranium Ore x 1", ref id3);
                UraniumLvl2 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL3 && UraniumLvl3 > 0)
            {
                InventoryShip.setCount(5, InventoryShip.getCount(5) + 1);
                Message.sendMessage("Uranium Ore x 1", ref id3);
                UraniumLvl3 -= 1;
            }
            else if (Carte1.level == LEVEL.LEVEL4 && UraniumLvl4 > 0)
            {
                InventoryShip.setCount(5, InventoryShip.getCount(5) + 1);
                Message.sendMessage("Uranium Ore x 1 :)", ref id3);
                UraniumLvl4 -= 1;
            }
        }
        else 
        {
            if (random > 140 && Carte1.level == LEVEL.LEVEL3 && res)
            {
                saber = SABER.YES;
                Message.sendMessage("NOW YOU HAVE THE LIGHTSABER", ref id4);
                res = false;
            }
            else
            {
                if (Carte1.level == LEVEL.LEVEL1 && StoneLvl1 > 0)
                {
                    InventoryShip.setCount(8, InventoryShip.getCount(8) + 1);
                    Message.sendMessage("Stone x 1", ref id4);
                    StoneLvl1 -= 1;
                }
                else if (Carte1.level == LEVEL.LEVEL2 && StoneLvl2 > 0)
                {
                    InventoryShip.setCount(8, InventoryShip.getCount(8) + 1);
                    Message.sendMessage("Stone x 1", ref id4);
                    StoneLvl2 -= 1;
                }
                else if (Carte1.level == LEVEL.LEVEL3 && StoneLvl3 > 0)
                {
                    InventoryShip.setCount(8, InventoryShip.getCount(8) + 1);
                    Message.sendMessage("Stone x 1", ref id4);
                    StoneLvl3 -= 1;
                }
                else if (Carte1.level == LEVEL.LEVEL4 && StoneLvl4 > 0)
                {
                    InventoryShip.setCount(8, InventoryShip.getCount(8) + 1);
                    Message.sendMessage("Stone x 1", ref id4);
                    StoneLvl4 -= 1;
                }
            }
            
        }
    }

    public enum SABER
    {
        NO,
        YES,
    }

}
