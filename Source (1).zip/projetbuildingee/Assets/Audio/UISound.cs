using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISound : MonoBehaviour
{
    public GameObject machineWindow;
    bool isOpen = false;

    void Update()
    {
        if (machineWindow.active)
        {
            if (!isOpen)
            {
                GetComponent<AudioSource>().Play(0);
                isOpen = true;
            }
        }
        if (!machineWindow.active)
            isOpen = false;
    }
}
