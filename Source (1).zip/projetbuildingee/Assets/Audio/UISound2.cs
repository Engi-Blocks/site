using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISound2 : MonoBehaviour
{
    public GameObject machineWindow;
    public GameObject perso;
    bool isOpen = false;

    void Update()
    {
        float x = perso.transform.position.x;
        float y = perso.transform.position.y;

        if (x > 2 && machineWindow.active)
        {
            if (!isOpen)
            {
                GetComponent<AudioSource>().Play(0);
                isOpen = true;
            }
        }
        if (!machineWindow.active)
            isOpen = false;
    }
}

