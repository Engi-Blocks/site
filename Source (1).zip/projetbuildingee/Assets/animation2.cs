using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class animation2 : MonoBehaviour
{
    public GameObject fenetre;
    public GameObject planete1;
    public GameObject planete2;
    public GameObject planete3;
    public GameObject terre;
    public Image carte;
    public static int messageID;
    public Text escape;
    public GameObject perso;

    void Start()
    {
        escape = GameObject.FindGameObjectWithTag("escape").GetComponent<Text>();
    }

    public void CloseAnimation()
    {
        fenetre.active = false;
        planete1.active = false;
        planete2.active = false;
        planete3.active = false;
        terre.active = false;
        carte.enabled = false;

        escape.enabled = false;
        Message.sendMessage("PRESS M TO OPEN THE MAP", ref messageID);
    }

    void Update()
    {
        perso.GetComponent<MOVE>().enabled = false;
    }
}
