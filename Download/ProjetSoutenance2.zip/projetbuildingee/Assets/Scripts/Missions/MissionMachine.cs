using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissionMachine : MonoBehaviour
{
    // Start is called before the first frame update
    private static int id;
    void Start()
    {
        id = 0;
    }

    // Update is called once per frame
    void Update()
    {
        GameObject X = GameObject.Find("perso_0");
        float x = X.transform.position.x;
        float y = X.transform.position.y;       
        if (y>2.5 && x<-4.5)
        {
            Message.sendMessage("PRESS T TO OPEN MISSION RECAP",ref id);            
        }
        else
        {
            Message.clear(ref id);
        }
       
    }
}
