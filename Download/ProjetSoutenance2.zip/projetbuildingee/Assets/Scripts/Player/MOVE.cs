using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MOVE : MonoBehaviour
{
    public float moveSpeed;
    public Rigidbody2D rb;
    private Vector3 velocity = Vector3.zero;
    public bool isJumping;
    public float JumpForce;
    public bool isGrounded;

    public Transform groundCheckLeft;
    public Transform groundCheckRight;


    public Animator animator;

    //SONS DEPLACEMENTS
    void Update ()
    {
        if ((Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.LeftArrow)) && isGrounded)
            GetComponent<AudioSource>().UnPause();
        else
            GetComponent<AudioSource>().Pause();
    }



    void FixedUpdate()
    {
        float horizontalMovement = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
        isGrounded = Physics2D.OverlapArea(groundCheckLeft.position, groundCheckRight.position);
        if (Input.GetButton("Jump") && isGrounded)
        {
            isJumping = true;
        }
        if (rb.velocity.x<-0.3)
            animator.SetFloat("Vitesse", 3);
        if (rb.velocity.x > 0)
            animator.SetFloat("Vitesse", 1);
        

        MovePlayer(horizontalMovement);
        float characterVelocity = Mathf.Abs(rb.velocity.x);
        animator.SetFloat("Speed", characterVelocity);
        animator.SetFloat("Saut", 8);
        if (!isGrounded)
        {
            animator.SetFloat("Saut", 12);
            animator.SetFloat("Speed", 0);
        }
        Upstairs();
    }

    void MovePlayer(float _horizontalMovement)
    {
        Vector3 targetVelocity = new Vector2(_horizontalMovement, rb.velocity.y);
        rb.velocity = Vector3.SmoothDamp(rb.velocity, targetVelocity, ref velocity, .05f);
        if (isJumping)
        {
            rb.AddForce(new Vector2(0f, JumpForce));
            isJumping = false;
        }
    }

    void Upstairs()
    {
        GameObject X = GameObject.Find("perso_0");
        float x = X.transform.position.x;
        float y = X.transform.position.y;
        if (y<-2 && x <2 && x>-2)
        {
            if (Input.GetKeyDown(KeyCode.U))
            {
                while (y<4)
                {
                    y = X.transform.position.y;
                    transform.position = new Vector3(x, y + 0.1f, 0);
                }
                
            }
        }
    }
}
