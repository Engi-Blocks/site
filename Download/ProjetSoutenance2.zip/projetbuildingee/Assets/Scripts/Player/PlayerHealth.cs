using UnityEngine.UI;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public int Maxhealth = 100;
    public int currentHealth;
    public float yplayer;
    public float xplayer;
    public float yMonster1;
    public float xMonster1;
    public float xMonster2;
    public float yMonster2;
    float a;
    float b;
    public GameObject Y;
    public GameObject Y2;

    public HealthBar healthBar;
    void Start()
    {
        currentHealth = Maxhealth;
        healthBar.SetMaxHealth(Maxhealth);
    }
    
    void Update()
    {       
        if (Input.GetKeyDown(KeyCode.H))
        {
            TakeDamage1(10);
            //testItems
            InventoryShip.setCountDeltaSafe(3, -23);
        }      
        xplayer = this.gameObject.transform.position.x;
        yplayer = this.gameObject.transform.position.y;
        xMonster1 = Y.gameObject.transform.position.x;
        yMonster1 = Y.gameObject.transform.position.y;
        xMonster2 = Y2.gameObject.transform.position.x;
        yMonster2 = Y2.gameObject.transform.position.y;
        if (Time.time - a >= 2)
        {
            if ((yplayer < 0 && yMonster1 < 0) || (yplayer > 0 && yMonster1 > 0))
            {
                if (Abs(xplayer) - Abs(xMonster1) < 1 && Abs(xplayer) - Abs(xMonster1) > -1)
                {
                    TakeDamage1(5);
                }
            }
            a = Time.time;
        }
        if (Time.time - b >= 4 && ((yplayer < 0 && yMonster2 < 0) || (yplayer > 0 && yMonster2 > 0)))
        {           
            if (Abs(xplayer) - Abs(xMonster2) < 1.5 && Abs(xplayer) - Abs(xMonster2) > -1.5 )
            {
                TakeDamage1(8);
            }
            b = Time.time;
        }

    }

    void TakeDamage1(int damage)
    {
        currentHealth -= damage;
        healthBar.SetHealth(currentHealth);
    }

    public float Abs(float res)
    {
        if (res <= 0)
            return -res;
        else
            return res;
              
    }
}
