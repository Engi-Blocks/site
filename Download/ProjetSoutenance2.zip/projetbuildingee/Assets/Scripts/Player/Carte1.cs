using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Carte1 : MonoBehaviour
{
    public bool cp1;
    public bool cp2;
    public bool cp3;
    public bool cp4;
    int id1;
    int id2;
    int id3;
    int id4;
    public GameObject monstre1;
    public GameObject monstre2;    

    void Start()
    {
        cp1 = true;
        cp2 = true;
        cp3 = true;
        cp4 = false;
        id1 = 0;
        id2 = 0;
        id3 = 0;
        id4 = 0;
  
    }
    public void p1()
    {              
        if (cp1)
        {           
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp1 = false;
        }
        else
        {

        }
    }

    public void p2()
    {
      
        if (cp2)
        {            
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp2 = false;
        }
        else
        {

        }
    }

    public void p3()
    {
        
        if (cp3)
        {           
            monstre1.SetActive(true);
            monstre2.SetActive(true);
            cp3 = false;
        }
        else
        {

        }
    }

    public void Terre()
    {
        if (cp4)
        {
            cp4 = false;
        }
        else
        {

        }
    }
}
