using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface SaveInterface
{
    object saveGame();
    string getKeySaveGame(); 
    bool loadGame(object save);//return true si il y a une erreur
    void loadNewGame();
    Type getTypeDataSave();
}
