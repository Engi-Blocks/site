using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoveMonster : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed = 2;
    private Transform posM;
    private GameObject Y;
    public float y1;
    public float y2;
    public  float life;
    public  int damage;
    public Animator animator;
    private float a;
    private int b;

    void Start()
    {
        transform.position = new Vector3(-4f, 4f, 0);
        life = 100;
        damage = 5;
        this.gameObject.SetActive(false);
        a = 0;
        b = 0;
    }

    // Update is called once per frame
    void Update()
    {
        Y = GameObject.Find("perso_0");
        y1 = Y.transform.position.y;
        y2 = this.gameObject.transform.position.y;
        if (y1<3 && y2 >2 && this.gameObject.transform.position.x<1)
        {          
            transform.Translate(Vector3.right * speed * Time.deltaTime);          
        }
        else if (y1 < 3 && y2 < 3)
        {
            if (this.gameObject.transform.position.x> Y.transform.position.x)
            {
                transform.Translate(Vector3.left * speed * Time.deltaTime);
            }
            else
            { 
                transform.Translate(Vector3.right * speed * Time.deltaTime);                
            }
           
        }
        if (life <=0)
        {
            transform.position = new Vector3(-4f, 4f, 0);
            a = a + 20;
            b = b + 2;
            life = 100 + a;
            damage = 5 + b;
            this.gameObject.SetActive(false);
        }
        if (Input.GetKeyDown(KeyCode.K))
        {
            life -= 10;
        }
        if (this.gameObject.transform.position.x > Y.transform.position.x)
        {
            animator.SetFloat("Left", 8);
        }
        else
        {
            animator.SetFloat("Left", 0);
        }
    }

    public void SetAttribute1(float _life, int _damage)
    {
        life = _life;
        damage = _damage;
    }

    public float Getlife1()
    {
        return life;
    }

    public int Getdamage1()
    {
        return damage;
    }



}
