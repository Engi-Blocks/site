namespace Items
{
    public interface EventItem
    {
        void changeCount(Item item, int deltaCount);
    }
}