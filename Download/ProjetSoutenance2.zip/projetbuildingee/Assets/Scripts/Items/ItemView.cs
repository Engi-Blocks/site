using UnityEngine.UI;
using UnityEngine;

public class ItemView
{
    public Item item;
    public ItemData itemData;
    public GameObject parentObject;
    public GameObject objectItem;
    public GameObject objectImage;
    public GameObject objectNameText;
    public GameObject objectCountText;
    public RectTransform rectItem;
    public RectTransform rectImage;
    public RectTransform rectName;
    public RectTransform rectCount;
    public Image image;
    public Text nameText;
    public Text countText;

    public ItemView(Item item,ItemData itemData,GameObject parent)
    {
        this.item = item;
        this.itemData = itemData;
        parentObject = parent;
    }
    
    public void createCanvas()
    {
        objectItem = new GameObject("Item "+ itemData.name +" id=" + itemData.id);
        rectItem = objectItem.AddComponent<RectTransform>();
        rectItem.SetParent(parentObject.transform);
        /*rectItem.anchoredPosition = new Vector2(posX,0f);
        rectItem.pivot = new Vector2(0f,0.5f);
        rectItem.anchorMax = new Vector2(0f, 0.5f);
        rectItem.anchorMin = new Vector2(0f, 0.5f);
        rectItem.sizeDelta = new Vector2(32f, 32f);*/
        objectImage = new GameObject("sprite");
        objectNameText = new GameObject("name");
        objectCountText = new GameObject("count");
        image = objectImage.AddComponent<Image>();
        image.sprite = itemData.Sprite;
        rectImage = (RectTransform) image.transform;
        rectImage.SetParent(rectItem);
        rectImage.anchoredPosition = new Vector2();
        rectImage.sizeDelta = new Vector2(32f, 32f);
        rectImage.anchorMax = new Vector2(0.5f, 0.5f);
        rectImage.anchorMin = new Vector2(0.5f, 0.5f);
        nameText=objectNameText.AddComponent<Text>();
        rectName= (RectTransform)nameText.transform;
        rectName.SetParent(rectItem);
        rectName.anchoredPosition = new Vector2(0f,-12f);
        rectName.anchorMax = new Vector2(0.5f,0f);
        rectName.anchorMin = new Vector2(0.5f,0f);
        rectName.pivot = new Vector2(0.5f,0f);
        nameText.text = itemData.name;
        nameText.font = Font.CreateDynamicFontFromOSFont("Arial", 11);
        nameText.alignment = TextAnchor.LowerCenter;
        nameText.fontSize = 11;
        nameText.color=Color.white;
        countText=objectCountText.AddComponent<Text>();
        rectCount = (RectTransform)countText.transform;
        rectCount.SetParent(rectItem);
        rectCount.anchoredPosition = new Vector2();
        rectCount.anchorMax = new Vector2(1f,0.5f);
        rectCount.anchorMin = new Vector2(1f,0.5f);
        rectCount.pivot = new Vector2(0f,0.5f);
        countText.alignment = TextAnchor.MiddleLeft;
        countText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        countText.fontSize = 14;
        countText.color=Color.white;
    }
    
    public void updateCountCanvas(uint count)
    {
        countText.text="x"+count;
    }

    public void clearCount()
    {
        countText.text = "";
    }

    public void removeCanvas()
    {
        RectTransform.Destroy(rectCount);
        RectTransform.Destroy(rectImage);
        RectTransform.Destroy(rectItem);
        RectTransform.Destroy(rectName);
        Image.Destroy(image);
        Text.Destroy(countText);
        Text.Destroy(nameText);
        GameObject.Destroy(objectNameText);
        GameObject.Destroy(objectCountText);
        GameObject.Destroy(objectImage);
        GameObject.Destroy(objectItem);
    }

}
