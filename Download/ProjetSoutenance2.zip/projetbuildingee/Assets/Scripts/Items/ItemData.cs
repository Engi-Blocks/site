using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName="ItemData", menuName="My Game/Item/Item")]
public class ItemData : ScriptableObject
{
    public int id;
    public Sprite Sprite;
    public string name;
    public string description;
    public string type;
    public uint defaultCount;
}
