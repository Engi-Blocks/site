using System;
using System.Collections.Generic;
using Items;
using UnityEngine;

public class InventoryShip : MonoBehaviour, SaveInterface
{
    // Start is called before the first frame update
    public ItemData[] itemDatas;
    public static Dictionary<int, Item> items;
    public static Dictionary<int, ItemView> itemsViewBar;
    public static InventoryShip instance;
    public GameObject barItemsObject;

    void Start()
    {
        instance = this;
        Save.addSaveListener(this);

        items = new Dictionary<int, Item>();
        itemsViewBar = new Dictionary<int, ItemView>();
    }

    public object saveGame()
    {
        Dictionary<int, int> counts = new Dictionary<int, int>();
        foreach (var kv in items)
            counts[kv.Key] = kv.Value.getCount();
        return counts;
    }

    public string getKeySaveGame()
    {
        return "Items";
    }

    public bool loadGame(object result)
    {
        loadNewGame();
        foreach (var itemData in itemDatas)
            items[itemData.id] = new Item(itemData);
        if (result is Dictionary<int, int>)
        {
            foreach (var kv in (Dictionary<int, int>) result)
            {
                if (items.ContainsKey(kv.Key))
                    items[kv.Key].setCount(kv.Value);
            }
            return false;
        }
        
        return true;
    }

    public void loadViewItems()
    {
        int i = 0;
        foreach (var item in items.Values)
        {
            ItemView itemView = item.addViewItem(barItemsObject);
            itemsViewBar[item.itemData.id] = itemView;
            itemView.createCanvas();
            itemView.rectItem.anchoredPosition = new Vector2(i * 80, 0f);
            itemView.rectItem.pivot = new Vector2(0f, 0.5f);
            itemView.rectItem.anchorMax = new Vector2(0f, 0.5f);
            itemView.rectItem.anchorMin = new Vector2(0f, 0.5f);
            itemView.rectItem.sizeDelta = new Vector2(32f, 32f);
            i++;
            item.updateCountCanvas();
        }
    }

    public void loadNewGame()
    {
        itemDestroy();
        foreach (var itemData in itemDatas)
            items[itemData.id] = new Item(itemData);
        loadViewItems();
    }

    public Type getTypeDataSave()
    {
        return typeof(Dictionary<int, int>);
    }

    public static int getCount(int id)
    {
        return items[id].getCount();
    }
    public static Item getItem(int id)
    {
        return items[id];
    }
    public static void addListenerEvent(int id,EventItem eventItem)
    {
        items[id].addEventListener(eventItem);
    }

    public static void setCount(int id, int n)
    {
        items[id].setCount(n);
    }

    public static bool isContain(int id, int n)
    {
        return items[id].isContain(n);
    }

    public static bool setCountDeltaSafe(int id, int delta)
    {
        return items[id].setCountDeltaSafe(delta);
    }

    public static void itemDestroy()
    {
        foreach (var item in items)
            item.Value.destroyViews();
        items.Clear();
        itemsViewBar.Clear();
    }
}