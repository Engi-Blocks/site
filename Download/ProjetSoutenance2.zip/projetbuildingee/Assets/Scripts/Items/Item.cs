using System;
using System.Collections.Generic;
using Items;
using UnityEngine;
using UnityEngine.UI;
[Serializable]
public class Item
{
    //Instance
    private static GameObject rootObject;
    
    public ItemData itemData;
    public uint count;
    private List<ItemView> itemViews = new List<ItemView>();
    private List<EventItem> eventListener = new List<EventItem>();
    public Item(ItemData itemData, uint? count = null)
    {
        this.itemData = itemData;
        //posY = y;//Si plus d'items (sur deux niveaux)
        this.count = count == null ? itemData.defaultCount : (uint)count;
        updateCountCanvas();
    }

    public int getCount()
    {
        return (int)count;
    }

    public void setCount(int n)
    {
        count = (uint)(n<0?0:n);
        foreach (var variabEventItem in eventListener)
            variabEventItem.changeCount(this, (int)(n<0?-n:n-count));
        updateCountCanvas();
    }

    public bool isContain(int n)
    {
        return count >= n;
    }

    public bool setCountDeltaSafe(int delta)
    {
        if (count+delta >= 0)
        {
            count += (uint)delta;
            foreach (var variabEventItem in eventListener)
                variabEventItem.changeCount(this, delta);
            updateCountCanvas();
            return true;
        }
        return false;
    }

    public void addEventListener(EventItem eventItem)
    {
        if(!eventListener.Contains(eventItem))
            eventListener.Add(eventItem);
    }

    public ItemView addViewItem(GameObject parent)
    {
        ItemView res = new ItemView(this, itemData, parent);
        itemViews.Add(res);
        return res;
    }

    public void updateCountCanvas()
    {
        foreach (ItemView itemView in itemViews)
            itemView.updateCountCanvas(count);
    }
    public void setDefaultValue()
    {
        count=itemData.defaultCount;
    }

    public void destroyViews()
    {
        foreach (ItemView itemView in itemViews)
            itemView.removeCanvas();
        itemViews.Clear();
    }
}
