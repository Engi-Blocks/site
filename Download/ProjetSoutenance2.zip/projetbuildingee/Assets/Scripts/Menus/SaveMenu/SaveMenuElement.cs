using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class SaveMenuElement
{
    public static string selectId;
    public static Dictionary<string,SaveMenuElement> elements;
    public static GameObject contentObject;
    public static GameObject saveSelectObject;
    public static Sprite backgroundSprite;
    public static Font font;
    private static CultureInfo providerDate;
    public static GameObject menuObject;
    public static GameObject[] saveSelectObjects;
    

    public string path;

    GameObject itemObject;
    GameObject nameObject;
    GameObject lastDateObject;
    GameObject createDateObject;
    GameObject levelObject;

    RectTransform itemRec;
    RectTransform nameRec;
    RectTransform lastDateRec;
    RectTransform createDateRec;
    RectTransform levelRec;

    Image itemImage; 
    Button itemButton;
    Text nameText;
    Text lastDateText;
    Text createDateText;
    Text levelText;

    SaveMenuElement(string path, int id)
    {
        itemObject = new GameObject("" + id);
        nameObject = new GameObject("Name");
        lastDateObject = new GameObject("LastDate");
        createDateObject = new GameObject("CreateDate");
        levelObject = new GameObject("Level");

        itemRec = itemObject.AddComponent<RectTransform>();
        nameRec = nameObject.AddComponent<RectTransform>();
        lastDateRec = lastDateObject.AddComponent<RectTransform>();
        createDateRec = createDateObject.AddComponent<RectTransform>();
        levelRec = levelObject.AddComponent<RectTransform>();

        itemImage = itemObject.AddComponent<Image>();
        itemButton = itemObject.AddComponent<Button>();
        nameText = nameObject.AddComponent<Text>();
        lastDateText = lastDateObject.AddComponent<Text>();
        createDateText = createDateObject.AddComponent<Text>();
        levelText = levelObject.AddComponent<Text>();

        itemRec.SetParent(contentObject.transform);
        itemRec.anchoredPosition = new Vector2(10f, id * -70f - 10f);
        itemRec.sizeDelta = new Vector2(-20f, 60f);
        itemRec.pivot = new Vector2(0f, 1f);
        itemRec.localScale = new Vector3(1f, 1f, 1f);
        itemRec.anchorMin = new Vector2(0f, 1f);
        itemRec.anchorMax = new Vector2(1f, 1f);

        nameRec.SetParent(itemRec);
        nameRec.anchoredPosition = new Vector2(5f, -5f);
        nameRec.sizeDelta = new Vector2(300f, 23f);
        nameRec.localScale = new Vector3(1f, 1f, 1f);
        nameRec.pivot = new Vector2(0f, 1f);
        nameRec.anchorMin = new Vector2(0f, 1f);
        nameRec.anchorMax = new Vector2(0f, 1f);

        lastDateRec.SetParent(itemRec);
        lastDateRec.anchoredPosition = new Vector2(5f, 5f);
        lastDateRec.sizeDelta = new Vector2(300f, 17f);
        lastDateRec.localScale = new Vector3(1f, 1f, 1f);
        lastDateRec.pivot = new Vector2(0f, 0f);
        lastDateRec.anchorMin = new Vector2(0f, 0f);
        lastDateRec.anchorMax = new Vector2(0f, 0f);

        createDateRec.SetParent(itemRec);
        createDateRec.anchoredPosition = new Vector2(-5f, 5f);
        createDateRec.sizeDelta = new Vector2(300f, 17f);
        createDateRec.localScale = new Vector3(1f, 1f, 1f);
        createDateRec.pivot = new Vector2(1f, 0f);
        createDateRec.anchorMin = new Vector2(1f, 0f);
        createDateRec.anchorMax = new Vector2(1f, 0f);

        levelRec.SetParent(itemRec);
        levelRec.anchoredPosition = new Vector2(-5f, -5f);
        levelRec.sizeDelta = new Vector2(59f, 17f);
        levelRec.localScale = new Vector3(1f, 1f, 1f);
        levelRec.pivot = new Vector2(1f, 1f);
        levelRec.anchorMin = new Vector2(1f, 1f);
        levelRec.anchorMax = new Vector2(1f, 1f);

        itemImage.sprite = backgroundSprite;
        itemImage.type = Image.Type.Sliced;

        UnityAction test = new UnityAction(UnityAction);
        itemButton.onClick.AddListener(test);

        nameText.text = Path.GetFileNameWithoutExtension(path);
        nameText.font = font;
        nameText.alignment = TextAnchor.UpperLeft;
        nameText.fontSize = 20;
        nameText.color = Color.black;

        lastDateText.text =
            "Last: " + File.GetLastWriteTime(path).ToString("ddd dd MMM yyyy HH\\hmm", providerDate);
        lastDateText.font = font;
        lastDateText.alignment = TextAnchor.LowerLeft;
        lastDateText.color = Color.black;

        createDateText.text =
            "Create: " + File.GetCreationTime(path).ToString("ddd dd MMM yyyy HH\\hmm", providerDate);
        createDateText.font = font;
        createDateText.alignment = TextAnchor.LowerRight;
        createDateText.color = Color.black;

        levelText.text = "Level: 00";
        levelText.font = font;
        levelText.alignment = TextAnchor.UpperRight;
        levelText.color = Color.black;
        this.path = path;
    }

    public void select()
    {
        itemImage.color = new Color(0.38f,0.54f,0.83f);
    }

    public void unSelect()
    {
        itemImage.color = Color.white;
    }

    public void delete()
    {
        deleteUI();
        File.Delete(path);
    }

    public string getPath()
    {
        return path;
    }

    public void deleteUI()
    {
        if (selectId == path) selectId = "";
        GameObject.Destroy(itemObject);
    }

    private void UnityAction()
    {
        if (selectId == "")
        {
            select();
            setSelect(path);
        }else if (selectId == path)
        {
            unSelect();
            setUnSelect();
        }
        else
        {
            elements[selectId].unSelect();
            select();
            setSelect(path);
        }
    }

    public static void destroyAll()
    {
        setUnSelect();
        if (elements == null)
        {
            elements = new Dictionary<string, SaveMenuElement>();
        }else{
            foreach (var VARIABLE in elements.Values)
            {
                VARIABLE.deleteUI();
            }
            elements.Clear();
        }
    }

    public static void start(Sprite backgroundSprite,GameObject[] saveSelectObjects)
    {
        SaveMenuElement.saveSelectObjects = saveSelectObjects;
        destroyAll();
        contentObject = GameObject.Find("Canvas/MenuSave/Elemens/Viewport/Content");
        saveSelectObject = GameObject.Find("Canvas/MenuSave/SaveSelect"); 
        font = Font.CreateDynamicFontFromOSFont("Arial",14);
        providerDate = new System.Globalization.CultureInfo("fr-FR");
        menuObject = GameObject.Find("Canvas/MenuSave");
        SaveMenuElement.backgroundSprite = backgroundSprite;
        //Debug.Log(saveSelectObject.transform.childCount);
    }

    public static void update()
    {
        destroyAll();
        int n = 0;
        foreach (var filePath in Directory.GetFiles(Save.pathDirectorySave, "*.engiblock"))
        {
            elements[filePath]=new SaveMenuElement(filePath, n);
            n++;
        }
        contentObject.GetComponent<RectTransform>().sizeDelta = new Vector2(0f,n*70f+10f);
    }

    public static void deleteButton()
    {
        if(selectId=="")return;
        elements[selectId].delete();
        update();
    }

    public static bool isOpen()
    {
        return menuObject.activeSelf;
    }

    public static void openUI()
    {
        menuObject.SetActive(true);
        update();
    }

    public static void closeUI()
    {
        destroyAll();
        menuObject.SetActive(false);
    }

    static public void setSelect(string id)
    {
        selectId = id;
        foreach (GameObject v in saveSelectObjects)
        {
            v.GetComponent<Button>().interactable = true;
        }
    }

    static public void setUnSelect()
    {
        selectId = "";
        foreach (GameObject v in saveSelectObjects)
        {
            //if(v==null)continue;
            //Debug.Log(v.name);
            //Debug.Log(v.GetComponent<Button>());
            v.GetComponent<Button>().interactable = false;
        }
    }
    
    public static void saveOverButton()
    {
        if (selectId != "")
            Save.saveAndWrite(elements[selectId].getPath());
    }

    public static void loadButton()
    {
        if (selectId == "") return;
        Save.readAndLoad(elements[selectId].getPath());
        closeUI();
    }
}