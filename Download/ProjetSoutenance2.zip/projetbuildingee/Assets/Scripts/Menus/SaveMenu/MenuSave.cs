using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class MenuSave : MonoBehaviour
{
    public GameObject contentObject;
    public Sprite backgroundSprite;
    public Font font;
    static private CultureInfo providerDate = new System.Globalization.CultureInfo("fr-FR");
    public GameObject[] saveSelectObjects;

    //public GameObject scrollObject;
    // Start is called before the first frame update
    void Start()
    {
        SaveMenuElement.start(backgroundSprite, saveSelectObjects);
        SaveMenuElement.update();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void buttonDelete()
    {
        SaveMenuElement.deleteButton();
    }

    public void buttonSaveOver()
    {
        SaveMenuElement.saveOverButton();
    }

    public void buttonLoad()
    {
        SaveMenuElement.loadButton();
    }

    public void buttonNewGame()
    {
        Save.loadNewGame();
        SaveMenuElement.closeUI();
    }
}
