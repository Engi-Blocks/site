using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject tittle;
    public GameObject settingsWindow;

    private void Start()
    {
        Screen.fullScreen = true;
    }

    public void StartGame()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public void SettingsButton()
    {
        settingsWindow.SetActive(true);
        tittle.SetActive(false);
    }

    public void CloseSettingsWindow()
    {
        settingsWindow.SetActive(false);
        tittle.SetActive(true);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
