using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Audio;
using System.Linq;
using UnityEngine.UI;

public class SettingsMenu : MonoBehaviour
{
    public AudioMixer audioMixer;
    public Dropdown dropdownResolution;
    Resolution[] resolutions;
    public Slider sliderVolume;
    public Slider sliderSound;

    public void Start()
    {
        resolutions = Screen.resolutions.Select(resolution => new Resolution { width = resolution.width, height = resolution.height }).Distinct().ToArray();
        dropdownResolution.ClearOptions();
        int currentResolutionIndex = 0;

        List<string> options = new List<string>();

        dropdownResolution.value = PlayerPrefs.GetInt("Resolution");
        sliderSound.value = PlayerPrefs.GetFloat("SoundVolume", 0.75f);
        sliderVolume.value = PlayerPrefs.GetFloat("MusicVolume", 0.75f);

        for (int i = 0; i < resolutions.Length; i += 1)
        {
            string option = resolutions[i].width + "x" + resolutions[i].height;
            options.Add(option);
            if (i + 1 == resolutions.Length)
            {
                if (resolutions[i].width == Screen.width && resolutions[i].height == Screen.height)
                    currentResolutionIndex = i;
                options.Add(option);
            }
            if (resolutions[i].width == Screen.width && resolutions[i].height == Screen.height)
                currentResolutionIndex = i;

        }
        dropdownResolution.AddOptions(options);
        dropdownResolution.value = currentResolutionIndex;
        dropdownResolution.RefreshShownValue();
    }

    public void SetVolume(float volume)
    {
        audioMixer.SetFloat("Music", Mathf.Log10(volume) * 20);
        PlayerPrefs.SetFloat("MusicVolume", volume);
    }
    
    public void SetSoundVolume(float volume)
    {
        audioMixer.SetFloat("Sound", Mathf.Log10(volume) * 20);
        PlayerPrefs.SetFloat("SoundVolume", volume);
    }

    public void SetResolution(int resolutionIndex)
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
        PlayerPrefs.SetInt("Resolution", resolutionIndex);
    }

    public void SetFullScreen(bool isFullScreen)
    {
        Screen.fullScreen = isFullScreen;
    }
}
