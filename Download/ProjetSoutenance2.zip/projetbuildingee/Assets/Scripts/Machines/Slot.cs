using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Machines
{
    public class Slot
    {
        private bool isInput;
        private ItemData[] itemDatas;
        private Vector2 pos;
        private Item item;
        private ItemView itemView;
        private Machine machine;
        private GameObject parentObject;
        private GameObject buttonObject;
        private RectTransform parentRect;
        private RectTransform buttonRect;
        private Button button;
        public Slot(bool isInput, ItemData[] itemDatas, Vector2 pos, Machine machine)
        {
            this.isInput = isInput;
            this.itemDatas = itemDatas;
            this.pos = pos;
            this.machine = machine;
            parentObject = new GameObject();
            buttonObject = new GameObject();
            parentRect = parentObject.AddComponent<RectTransform>();
            button = buttonObject.AddComponent<Button>();
            buttonRect = (RectTransform)button.transform;
            button.onClick.AddListener(new UnityAction(UnityAction));
        }

        private void UnityAction()
        {
            throw new System.NotImplementedException();
        }

        public void setVisibled(bool isVisible)
        {
            throw new System.NotImplementedException();
        }

        public void setSelectItems(ItemData select)
        {
            throw new System.NotImplementedException();
        }

        public void setCountOutput(uint count)
        {
            throw new System.NotImplementedException();
        }

        public void Destroy()
        {
            GameObject.Destroy(parentObject);
        }

    }
}