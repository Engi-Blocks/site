using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using UnityEngine;

[CreateAssetMenu(fileName="MachineData", menuName="My Game/Machine/Machine")]
public class MachineData : ScriptableObject
{
    public Level[] levels;
    public recipe[] recipes;
    public Slot[] slotsInput;
    public Slot slotOuput;
    public string nameMachine;
    public string descriptionMachine;
    
    public Sprite spriteMachine;
    
    public bool isBarInProgress;
    public Sprite spriteBarInProgress;
    public Color colorBarInProgress;

    public GameObject Panel;
    public Sprite background;
    

    [Serializable]
    public class Level
    {
        public Item[] itemsForLevel;
        public int energyForLevel;
        public int powerPasif;
    }
    [Serializable]
    public class recipe
    {
        public Item[] itemsInput;
        public Item itemOutput;
        public int powerActif;
        public int time;//en seconde
        public int requireLevel;
    }

    [Serializable]
    public class Slot
    {
        public Vector2 position;
    }
}
