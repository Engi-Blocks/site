using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ship : MonoBehaviour, SaveInterface
{
    public List<Machine> machines = new List<Machine>();

    public int energyStorage;
    public int energyCapacity;

    public bool isPause;

    public int puissanceDelta;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    

    public object saveGame()
    {
        throw new NotImplementedException();
    }

    public string getKeySaveGame()
    {
        throw new NotImplementedException();
    }

    public bool loadGame(object save)
    {
        throw new NotImplementedException();
    }

    public void loadNewGame()
    {
        throw new NotImplementedException();
    }

    public Type getTypeDataSave()
    {
        throw new NotImplementedException();
    }
}
