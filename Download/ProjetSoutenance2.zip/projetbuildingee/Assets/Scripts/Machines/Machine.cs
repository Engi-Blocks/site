using System;
using System.Collections;
using System.Collections.Generic;
using Machines;
using UnityEngine;

public class Machine
{
    public int level;
    public int health;
    public int recipe;//si -1 pas de recipe
    public int processedTime;//si 0 process finish
    public MachineData machineData;
    
    Machine()
    {
        throw new System.NotImplementedException();
    }

    public int update()
    {
        if (processedTime > 0)
        {
            inProcesse();
            processedTime--;
        }else if (recipe != -1)
        {
            processeFinish();
            recipe = -1;
        }
        else
        {
            noProcesse();
        }
        return getPower();
    }

    public void inProcesse()
    {
        throw new System.NotImplementedException();
    }

    public void processeFinish()
    {
        throw new System.NotImplementedException();
    }

    public void noProcesse()
    {
        throw new System.NotImplementedException();
    }

    public void playerGetItemSlotOutput(Slot slot)//event
    {
        throw new System.NotImplementedException();
    }

    public void playerSelecteItemSlotInput(Slot slot)//event
    {
        throw new System.NotImplementedException();
    }

    public int getPower()
    {
        return recipe == -1?machineData.levels[level].powerPasif:machineData.recipes[recipe].powerActif;
    }
    
}
