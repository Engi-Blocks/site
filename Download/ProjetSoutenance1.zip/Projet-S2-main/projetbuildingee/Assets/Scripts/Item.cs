using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Item
{
    //Static
    static Dictionary<int, Item> items;
    
    //Instance
    private static GameObject rootObject;
    private int count;
    public ItemData itemData;
    private int posX;
    //private int posY;

    private GameObject objectItem;
    private GameObject objectImage;
    private GameObject objectNameText;
    private GameObject objectCountText;
    private RectTransform rectItem;
    private RectTransform rectImage;
    private RectTransform rectName;
    private RectTransform rectCount;
    private Image image;
    private Text nameText;
    private Text countText;

    static public void start(ItemData[] itemDatas)
    {
        if (rootObject == null)
        {
            rootObject=GameObject.Find("Canvas/Items");
            items = new Dictionary<int, Item>();
            int i = 0;
            foreach (var itemData in itemDatas)
            {
                items[itemData.id] = new Item(i*80, itemData);
                i++;
            }
        }
        else
        {
            Debug.LogError("Antoine: double start en static sur item");
        }
    }
    public static int getCount(int id)
    {
        return items[id].getCount();
    }

    public static void setCount(int id, int n)
    {
        items[id].setCount(n);
    }

    public static bool isContain(int id, int n)
    {
        return items[id].isContain(n);
    }

    public static bool setCountDeltaSafe(int id, int delta)
    {
        return items[id].setCountDeltaSafe(delta);
    }

    public void updateCountCanvas()
    {
        countText.text="x"+count;
    }

    Item(int x, ItemData itemData)
    {
        this.itemData = itemData;
        posX = x;
        //posY = y;//Si plus d'items (sur deux niveaux)
        count = itemData.defaultCount;
        createCanvas();
    }
    
    public void createCanvas()
    {
        objectItem = new GameObject("Item " + itemData.id);
        rectItem = objectItem.AddComponent<RectTransform>();
        rectItem.SetParent(rootObject.transform);
        rectItem.anchoredPosition = new Vector2(posX,0f);
        rectItem.pivot = new Vector2(0f,0.5f);
        rectItem.anchorMax = new Vector2(0f, 0.5f);
        rectItem.anchorMin = new Vector2(0f, 0.5f);
        rectItem.sizeDelta = new Vector2(32f, 32f);
        objectImage = new GameObject("sprite");
        objectNameText = new GameObject("name");
        objectCountText = new GameObject("count");
        image = objectImage.AddComponent<Image>();
        image.sprite = itemData.Sprite;
        rectImage = (RectTransform) image.transform;
        rectImage.SetParent(rectItem);
        rectImage.anchoredPosition = new Vector2();
        rectImage.sizeDelta = new Vector2(32f, 32f);
        rectImage.anchorMax = new Vector2(0.5f, 0.5f);
        rectImage.anchorMin = new Vector2(0.5f, 0.5f);
        nameText=objectNameText.AddComponent<Text>();
        rectName= (RectTransform)nameText.transform;
        rectName.SetParent(rectItem);
        rectName.anchoredPosition = new Vector2(0f,10f);
        rectName.anchorMax = new Vector2(0.5f,1f);
        rectName.anchorMin = new Vector2(0.5f,1f);
        rectName.pivot = new Vector2(0.5f,0f);
        nameText.text = itemData.name;
        nameText.font = Font.CreateDynamicFontFromOSFont("Arial", 11);
        nameText.alignment = TextAnchor.LowerCenter;
        nameText.fontSize = 11;
        nameText.color=Color.white;
        countText=objectCountText.AddComponent<Text>();
        rectCount = (RectTransform)countText.transform;
        rectCount.SetParent(rectItem);
        rectCount.anchoredPosition = new Vector2();
        rectCount.anchorMax = new Vector2(1f,0.5f);
        rectCount.anchorMin = new Vector2(1f,0.5f);
        rectCount.pivot = new Vector2(0f,0.5f);
        countText.text = "x"+count;
        countText.alignment = TextAnchor.MiddleLeft;
        countText.font = Font.CreateDynamicFontFromOSFont("Arial", 14);
        countText.fontSize = 14;
        countText.color=Color.white;
    }

    public void removeCanvas()
    {
        RectTransform.Destroy(rectCount);
        RectTransform.Destroy(rectImage);
        RectTransform.Destroy(rectItem);
        RectTransform.Destroy(rectName);
        Image.Destroy(image);
        Text.Destroy(countText);
        Text.Destroy(nameText);
        GameObject.Destroy(objectNameText);
        GameObject.Destroy(objectCountText);
        GameObject.Destroy(objectImage);
        GameObject.Destroy(objectItem);
    }

    public int getCount()
    {
        return count;
    }

    public void setCount(int n)
    {
        count = n<0?0:n;
        updateCountCanvas();
    }

    public bool isContain(int n)
    {
        return count >= n;
    }

    public bool setCountDeltaSafe(int delta)
    {
        if (count+delta >= 0)
        {
            count += delta;
            updateCountCanvas();
            return true;
        }
        return false;
    }

    public static void loadDataSave(Dictionary<int, int> result)
    {
        foreach (var kv in result)
        {
            if(items.ContainsKey(kv.Key))
                items[kv.Key].setCount(kv.Value);
        }
    }

    public static object getDataSave()
    {
        Dictionary<int, int> counts = new Dictionary<int, int>();
        foreach (var kv in items)
        {
            counts[kv.Key] = kv.Value.getCount();
        }
        return counts;
    }
}
