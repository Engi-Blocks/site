using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using Button = UnityEngine.UIElements.Button;

public class MenuSave : MonoBehaviour
{
    public GameObject menu;
    public GameObject saveButton;
    public InputField inputNameFileSave;
    public string lastNameFile = "";
    public string nameFile = "";
    public Image mapIU;
    void Start()
    {
    }

    public void filterInput()
    {
        inputNameFileSave.text=getNameFormated();
    }
    public string getNameFormated()
    {
        string name = "";
                foreach (char c in inputNameFileSave.text)
                {
                    if ((c < 123 && c > 96) || (c < 91 && c > 64) || (c < 58 && c > 47) || c == 32 || c==95)
                    {
                        name += c;
                        if(name.Length > 32)
                            break;
                    }
                }

                return name;
    }

    public void loadLastSave()
    {
        string name = getNameFormated();
        if(name.Length==0)
            return;
        string path = Save.getPathFileSave(name);
        Debug.Log(path);
        if (File.Exists(path))
            Save.readAndLoad(path,false);
    }

    public void buttonSaveOnclick()
    {
        string name = getNameFormated();
        if(name.Length==0)
            return;
        Save.saveAndWrite(Save.getPathFileSave(name), false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && !mapIU.enabled)
        {
            menu.SetActive(!menu.activeSelf);
        }
    }
}
