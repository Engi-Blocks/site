using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour, SaveInterface
{
    private GameObject playerObject;
    private Transform playerTransform;
    public PlayerHealth playerHealth;
    // Start is called before the first frame update
    void Start()
    {
        playerObject = GameObject.Find("perso_0");
        playerTransform = playerObject.transform;
        Save.addSaveListener(this);
    }

    public object saveGame()
    {
        Dictionary<string, float> result = new Dictionary<string, float>();
        result["health"] = playerHealth.currentHealth;
        result["x"] = playerTransform.position.x;
        result["y"] = playerTransform.position.y;
        return result;
    }

    public string getKeySaveGame()
    {
        return "player";
    }

    public bool loadGame(object save)
    {
        Dictionary<string, float> res = (Dictionary<string, float>) save;
        if (res.ContainsKey("health") && res.ContainsKey("x") && res.ContainsKey("y"))
        {
            playerHealth.currentHealth=(int)res["health"];
            playerHealth.healthBar.SetHealth(playerHealth.currentHealth);
            playerTransform.position = new Vector3(res["x"], res["y"]);
            return false;
        }
        return true;
    }

    public Type getTypeDataSave()
    {
        return typeof(Dictionary<string, float>);
    }
}
