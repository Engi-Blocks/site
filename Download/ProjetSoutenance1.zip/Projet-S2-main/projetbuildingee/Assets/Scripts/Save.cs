using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Threading.Tasks;
using UnityEngine;
using Newtonsoft.Json;


public class Save
{
    private static Dictionary<string, SaveInterface> saveListener = new Dictionary<string, SaveInterface>();
    static readonly byte[] KEY_AES = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
    private static JsonSerializerSettings serializerSettings=new JsonSerializerSettings();
    public static string pathDirectorySave = Application.persistentDataPath + "/save/";
    public static void addSaveListener(SaveInterface saveIterface)
    {
        if (!saveListener.ContainsKey(saveIterface.getKeySaveGame()))
        {
            saveListener[saveIterface.getKeySaveGame()] = saveIterface;
        }
        else
            Debug.LogError("Antoine: deux save avec la meme key");
    }

    public static string getPathFileSave(string name)
    {
        return Save.pathDirectorySave + name + ".engiblock";
    }

    public static async Task saveAndWrite(string path, bool isCrypt)
    {
        Dictionary<string, string> save = new Dictionary<string, string>();
        foreach (var kv in saveListener)
        {
            try
            {
                object ser = kv.Value.saveGame();
                try
                {
                    save[kv.Key] = JsonConvert.SerializeObject(ser,kv.Value.getTypeDataSave(),serializerSettings);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
                //Debug.Log(JsonConvert.DeserializeObject(save[kv.Key]));
            }
            catch (Exception e)
            {
                Debug.LogError(e);
                Debug.LogError("Antoine: save serialisation impossible! key_for_save="+kv.Key);
                throw;
            }
        }
        string json = JsonConvert.SerializeObject(save);
        if (isCrypt)
        {
            try
            {
                MemoryStream myStream = new MemoryStream();
                StreamWriter writer = new StreamWriter(myStream);
                writer.Write(json);
                writer.Flush();
                myStream.Position = 0;
                using Aes aes = Aes.Create();
                aes.Key = KEY_AES;
                byte[] iv = aes.IV;
                myStream.Write(iv, 0, iv.Length);
                using CryptoStream cryptStream = new CryptoStream(
                    myStream, 
                    aes.CreateEncryptor(),
                    CryptoStreamMode.Write);
                using (StreamReader srDecrypt = new StreamReader(cryptStream))
                {
                    json = srDecrypt.ReadToEnd();
                }
            }
            catch
            {
                Debug.LogError("Antoine: save write chiffrement impossible!");
            }
        }
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            using StreamWriter file = new StreamWriter(path, append: false);
                await file.WriteAsync(json);
        }
        catch (Exception e)
        {
            Debug.LogError("Antoine: save write file impossible! path="+path);
        }
    }

    public static bool readAndLoad(string path, bool isCrypt)
    {
        try
        {
            string json = File.ReadAllText(path);
            if (isCrypt)
            {
                Debug.LogError("NON IMPLEMENTE");
            }
            try
            {
                Dictionary<string, string> save = JsonConvert.DeserializeObject<Dictionary<string,string>>(json);
                foreach (var kv in saveListener)
                {
                    if (save.ContainsKey(kv.Key))
                    {
                        try
                        {
                            object jsonObject = JsonConvert.DeserializeObject(save[kv.Key],kv.Value.getTypeDataSave());
                            try
                            {
                                if(kv.Value.loadGame(jsonObject))
                                    Debug.LogError("Antoine: read save loadGame error! key_for_save="+kv.Key);
                            }
                            catch (Exception e)
                            {
                                Debug.LogError("Antoine: read save loadGame Exception! key_for_save="+kv.Key);
                            }
                            
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Antoine: read save parsing json impossible! key_for_save="+kv.Key);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError("Antoine: read save parsing json impossible!");
            }
        }
        catch (Exception e)
        {
            Debug.LogError("Antoine: read save imposible (file n'existe pas) path="+path);
        }
        return false;
    }
}
