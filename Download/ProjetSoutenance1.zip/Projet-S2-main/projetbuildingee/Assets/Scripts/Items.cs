
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Items : MonoBehaviour, SaveInterface
{
    // Start is called before the first frame update
    public ItemData[] itemDatas;
    public bool isDebugLinuxAntoine;

    void Start()
    {
        Item.start(itemDatas);
        Save.addSaveListener(this);
        isDebugLinuxAntoine=Environment.UserName=="antoine" && Environment.OSVersion.Platform == PlatformID.Unix;
        isDebugLinuxAntoine = false;
    }

    private void Update()
    {
        if (isDebugLinuxAntoine)
        {
            if (Input.GetKeyDown(KeyCode.S))
                    {
                        Save.saveAndWrite("/home/antoine/Bureau/testSaveGame.json", false);
                    }
                    else if (Input.GetKeyDown(KeyCode.O))
                    {
                        Save.readAndLoad("/home/antoine/Bureau/testSaveGame.json", false);
                    }
        }
    }

    public object saveGame()
    {
        return Item.getDataSave();
    }

    public string getKeySaveGame()
    {
        return "Items";
    }

    public bool loadGame(object result)
    {
        if (result is Dictionary<int, int>)
        {
            Item.loadDataSave((Dictionary<int, int>) result);
            return false;
        }
        return true;
    }

    public Type getTypeDataSave()
    {
        return typeof(Dictionary<int, int>);
    }

}
