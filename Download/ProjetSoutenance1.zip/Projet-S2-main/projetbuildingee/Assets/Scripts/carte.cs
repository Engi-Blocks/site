using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class carte : MonoBehaviour
{
    private GameObject X;
    public float x;
    public bool Isin;
    public Text InteractUI;
    public Image Carte;
    public Text escape;
    
    void Awake()
    {
        InteractUI = GameObject.FindGameObjectWithTag("InteractUI").GetComponent<Text>();
        Carte = GameObject.FindGameObjectWithTag("carte").GetComponent<Image>();
        escape = GameObject.FindGameObjectWithTag("escape").GetComponent<Text>();
    }

    void Update()
    {
        X = GameObject.Find("perso_0");
        x = X.transform.position.x;
        if (x > 14)
            Isin = true;
        else
            Isin = false;
        if (Isin && !escape.enabled)
        {
            InteractUI.enabled = true;
        }
        else
        {
            InteractUI.enabled = false;
        }
        if (Isin)
        {
            bool isKeyDownM = Input.GetKeyDown(KeyCode.M);
            if (Carte.enabled)
            {
                if (Input.GetKeyDown(KeyCode.Escape) || isKeyDownM)
                { 
                    Carte.enabled = false; 
                    escape.enabled = false;
                }
            }
            else
            {
                if (isKeyDownM)
                { 
                    Carte.enabled = true; 
                    InteractUI.enabled = false;
                    escape.enabled = true;
                }
            }
        }
        else
        {
            Carte.enabled = false;
            escape.enabled = false;
        }

    }
}
